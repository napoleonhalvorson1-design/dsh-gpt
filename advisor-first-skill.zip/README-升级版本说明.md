# advisor-first 升级版 - DeepSeek优化版

**让DeepSeek真正看懂和使用的advisor-first技能包**

---

## 📦 这个包里有什么

```
.
├── advisor-first-skill/          ⭐ 主要内容：优化后的技能包
│   ├── SKILL.md                  # 技能定义(DSH会读取)
│   ├── README.md                 # 完整使用文档
│   ├── README-INSTALL.md         # 安装指南
│   ├── DEEPSEEK-GUIDE.md         # DeepSeek快速参考 ⭐ 核心
│   ├── EXAMPLES.md               # 4个实战示例
│   ├── UPGRADE.md                # 升级说明(本版改进)
│   ├── install.ps1               # 一键安装脚本
│   ├── advisor-first/            # 技能文件
│   │   ├── SKILL.md
│   │   └── scripts/
│   │       └── ask-advisor.mjs   # 核心脚本
│   └── tests/                    # 测试套件
│
└── advisor-first-工具包/          # 参考：原版工具包
    ├── ask-advisor.mjs           # 原版脚本
    ├── ask-deepseek.mjs          # DeepSeek API调用工具
    ├── FIXES.md                  # 详细的修复历史
    └── ...                       # 其他诊断和测试文件
```

---

## 🎯 核心改进

### 1. **DeepSeek能真正理解**

**问题**: 原版文档技术性强，DeepSeek难以快速判断何时使用

**解决**:
- ✅ **决策树** - 清晰的判断标准(修改≥3文件? 陌生领域? 重复失败?)
- ✅ **DEEPSEEK-GUIDE.md** - 专门给AI的快速参考指南
- ✅ **whenToUse/whenNotToUse** - 明确的使用和不使用场景
- ✅ **检查清单** - 使用前后的检查项

### 2. **完整的使用流程**

**问题**: 知道有这个工具，但不知道具体怎么用

**解决**:
- ✅ **标准提示词模板** - 包含必备结构(背景/目标/约束/我的判断/请回答)
- ✅ **质量检查清单** - 6项必查项，确保提示词质量
- ✅ **决策记录模板** - 如何记录采纳/拒绝的理由
- ✅ **4个实战示例** - API优化、CI调试、架构设计、新技术学习

### 3. **安全边界清晰**

**问题**: 不知道什么不该做

**解决**:
- ❌ 三道红线(走过场、盲从、当指令)
- ✅ 验证原则(路径/命令/API必须先验证)
- ✅ 记账要求(必须显式说明采纳或拒绝什么)

---

## 🚀 快速开始

### 安装(1分钟)

```powershell
cd advisor-first-skill
pwsh -File .\install.ps1
```

安装到: `~\.dsh-beta\skills\advisor-first\`

### 第一次使用

```powershell
# 在DSH中输入
/advisor-first

# 会看到完整的技能说明注入
```

### 给DeepSeek的使用流程

1. **判断是否需要** - 参考决策树(DEEPSEEK-GUIDE.md)
2. **准备提示词** - 使用标准模板(必含"我的判断")
3. **调用脚本** - `node <base>/scripts/ask-advisor.mjs --prompt-file Q.md --out A.md`
4. **记录决策** - 采纳/拒绝什么，为什么
5. **验证信息** - 顾问提到的路径/命令必须验证
6. **执行** - 告知用户采纳了哪些建议

---

## 📚 文档导航

**我是DeepSeek AI** → 先读 `advisor-first-skill/DEEPSEEK-GUIDE.md` (5分钟掌握核心)

**我是人类用户** → 先读 `advisor-first-skill/README.md` (完整文档)

**我要看怎么用** → 看 `advisor-first-skill/EXAMPLES.md` (4个真实场景)

**我要安装** → 看 `advisor-first-skill/README-INSTALL.md` (详细步骤)

**我想了解改进** → 看 `advisor-first-skill/UPGRADE.md` (v1.0→v1.2.0)

**我想看修复历史** → 看 `advisor-first-工具包/FIXES.md` (实测证据)

---

## ✅ 已验证特性

### 技术可靠性 (v1.1.0已修复)

- ✅ UTF-8边界安全 (StringDecoder跨chunk拼接)
- ✅ 三重看门狗 (首字节30s / 内容增长45s / 总时长120s)
- ✅ 自动重试+退避 (每模型3次)
- ✅ 模型回退链 (astra→sol→luna，失败时exit=1并明示)
- ✅ 透明的错误报告 (stderr显示详细进度)

### 文档完整性 (v1.2.0新增)

- ✅ 决策树和判断标准
- ✅ 提示词模板+检查清单
- ✅ 4个端到端实战示例
- ✅ DeepSeek专用快速参考
- ✅ 安全原则和三道红线

### 测试覆盖

```powershell
node advisor-first-skill/tests/run-tests.mjs
# ✅ 8/8 通过

node advisor-first-skill/tests/test-utf8-boundary.mjs
# ✅ 5/5 通过 (逐字节切分也完整)

node advisor-first-skill/tests/stress-exit.mjs 25
# ✅ 25/25 exit=0 (无间歇性崩溃)
```

---

## 🎯 核心价值

### 对DeepSeek的价值

- **外部视角** - 咨询GPT-6 Astra，避免单一思路的盲区
- **降低返工** - 架构和选型在执行前就得到验证
- **明确边界** - 知道何时该用、何时不该用
- **标准流程** - 从判断到执行的完整checklist

### 对用户的价值

- **提高质量** - 复杂决策得到多模型验证
- **节省时间** - 避免错误方向的返工
- **透明过程** - 看得到DeepSeek是否咨询了、采纳了什么
- **可靠工具** - 修复了UTF-8、超时等所有已知bug

---

## 📊 使用场景示例

### ✅ 应该使用

- 用户: "做一个博客系统" → **架构设计**
- 同一bug修了2次还没好 → **重复失败**
- 要重构涉及5个文件 → **跨模块改动**
- 用户要用Rust但DeepSeek不熟 → **陌生技术**
- 用户: "先问问GPT怎么做" → **明确要求**

### ❌ 不应该使用

- 修改变量名的拼写错误 → 简单修改，直接做
- 读取一个配置文件 → 基础操作，直接做
- 用户已说"用Express框架" → 方案已定，直接做
- 查询"什么是Docker" → 信息查询，直接答

---

## 🔧 性能特征

- **TTFT**: 1-2秒 (流式输出，快速反馈)
- **总耗时**: 5-40秒 (大部分问题<20秒)
- **单次上限**: 120秒 (超时自动中断)
- **最坏情况**: 5分钟 (含所有重试和模型回退)
- **Token消耗**: 短问题~300, 完整模板~12.5k

---

## ⚠️ 重要提醒

### 给DeepSeek

1. **不要走过场** - 咨询了就必须记录采纳/拒绝什么
2. **不要盲从** - 顾问说的路径/命令必须先验证
3. **不要小题大做** - 简单问题别咨询，浪费5-40秒
4. **必须记账** - 每次咨询后显式告知用户采纳了什么

### 给用户

1. **理解延迟** - 咨询需要5-40秒，这是正常的
2. **查看决策** - DeepSeek应该告诉你采纳了哪些建议
3. **验证输出** - 顾问的建议是参考，不是必须执行
4. **反馈质量** - 如果建议质量差，检查提示词是否包含"我的判断"

---

## 📞 获取帮助

### 安装问题

```powershell
# 测试安装
Test-Path ~\.dsh-beta\skills\advisor-first\SKILL.md
# 期望: True

# 在DSH中测试
/advisor-first
# 期望: 看到skill内容注入
```

### 使用问题

```bash
# 测试凭据和连接
node ~\.dsh-beta\skills\advisor-first\scripts\ask-advisor.mjs --list
# 期望: 列出模型, exit=0

# 快速测试
node ~\.dsh-beta\skills\advisor-first\scripts\ask-advisor.mjs --quiet "测试"
# 期望: 1-2秒返回, exit=0
```

### 文档问题

- **不知道何时用** → 看 `DEEPSEEK-GUIDE.md` 的决策树
- **不知道怎么用** → 看 `EXAMPLES.md` 的实战示例
- **不知道为什么** → 看 `UPGRADE.md` 的改进说明
- **遇到技术问题** → 看 `advisor-first-工具包/FIXES.md` 的修复历史

---

## ✨ 总结

**advisor-first v1.2.0** = 技术可靠 + 文档完善 + DeepSeek友好

- ✅ **技术**: 修复UTF-8、超时、模型回退等所有已知bug
- ✅ **文档**: 5个文档覆盖安装、使用、示例、参考、升级
- ✅ **AI友好**: 决策树、模板、检查清单，让DeepSeek真正会用

**现在开始使用**:

```powershell
cd advisor-first-skill
pwsh -File .\install.ps1
```

然后在DSH中输入 `/advisor-first`

**记住**: advisor-first是为复杂决策设计的工具，不是每个任务都需要咨询。简单问题直接做更快。
