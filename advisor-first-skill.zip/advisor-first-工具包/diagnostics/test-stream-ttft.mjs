#!/usr/bin/env node
/**
 * 定向验证：流式 + reasoning_effort=max 是否可用。
 *
 * 假设：非流式 + max effort 会因为"整段生成完才返回"而表现为长时间挂起，
 *       但流式能立刻拿到 TTFT，从而可以：
 *         ① 判断服务端到底有没有在干活
 *         ② 用 TTFT 做超时判据（而不是用总时长）
 *
 * 本脚本对每个 effort 值做流式调用，记录 TTFT 与总时长。
 */
import { readFileSync, appendFileSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';

const LOG = 'C:\\Users\\zzx123\\.local\\bin\\_advisor_stream.log';
writeFileSync(LOG, `=== stream + effort ${new Date().toISOString()} ===\n`);
const log = (s) => { process.stdout.write(s + '\n'); appendFileSync(LOG, s + '\n'); };

const cfg = readFileSync(join(homedir(), '.codex', 'config.toml'), 'utf8');
const TOKEN = cfg.match(/experimental_bearer_token\s*=\s*"([^"]+)"/)[1];
const BASE = cfg.match(/base_url\s*=\s*"([^"]+)"/)[1].replace(/\/+$/, '');

const PROMPT = '请写一段 200 字左右的说明，解释为什么日志清理脚本需要 -DryRun 开关。';
const TRIALS = Number(process.argv[2] || 2);

async function stream(effort, timeoutMs) {
  const body = {
    model: 'gpt-6-astra',
    messages: [{ role: 'user', content: PROMPT }],
    max_tokens: 600,
    stream: true,
  };
  if (effort !== null) body.reasoning_effort = effort;

  const t0 = Date.now();
  let ttft = null;
  let bytes = 0;
  try {
    const r = await fetch(`${BASE}/chat/completions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${TOKEN}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs),
    });
    if (!r.ok) return { ok: false, ms: Date.now() - t0, ttft: null, kind: `HTTP ${r.status}`, detail: (await r.text()).slice(0, 150) };
    let buf = '';
    for await (const chunk of r.body) {
      buf += Buffer.from(chunk).toString('utf8');
      bytes = buf.length;
      if (ttft === null && /"content"\s*:\s*"[^"]/.test(buf)) ttft = Date.now() - t0;
      if (buf.includes('[DONE]')) break;
    }
    return { ok: ttft !== null, ms: Date.now() - t0, ttft, bytes, kind: ttft !== null ? 'OK' : 'NO_CONTENT' };
  } catch (e) {
    const kind = e?.name === 'TimeoutError' || e?.name === 'AbortError' ? `HANG>${timeoutMs}ms` : e?.name || 'Error';
    return { ok: false, ms: Date.now() - t0, ttft, bytes, kind };
  }
}

for (const eff of ['max', 'high', 'low', null]) {
  log(`\n### stream, reasoning_effort = ${eff === null ? '(不发)' : JSON.stringify(eff)}  × ${TRIALS}`);
  for (let i = 1; i <= TRIALS; i++) {
    const r = await stream(eff, 70000);
    log(`  #${i} ${r.ok ? 'OK  ' : 'FAIL'} total=${String(r.ms).padStart(6)}ms  ttft=${r.ttft === null ? '  none' : String(r.ttft).padStart(6) + 'ms'}  bytes=${r.bytes}  ${r.kind}${r.detail ? '  ' + r.detail.replace(/\s+/g, ' ') : ''}`);
  }
}
