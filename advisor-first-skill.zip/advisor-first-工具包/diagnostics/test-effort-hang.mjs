#!/usr/bin/env node
/**
 * 变量隔离实验：reasoning_effort 取值 是否导致挂起？
 *
 * 观察到的现象：
 *   · 诊断脚本（不发 reasoning_effort）→ 1.2–1.6s 成功
 *   · ask-advisor.mjs（发 reasoning_effort:"max"）→ 偶发长时间挂起，CPU≈0，deadline 不触发
 *
 * 本脚本控制所有其他变量不变（同模型、同 prompt、同 max_tokens、同非流式），
 * 只改 reasoning_effort，看哪个取值会挂。
 */
import { readFileSync, appendFileSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';

const LOG = 'C:\\Users\\zzx123\\.local\\bin\\_advisor_effort.log';
writeFileSync(LOG, `=== reasoning_effort isolation ${new Date().toISOString()} ===\n`);
const log = (s) => { process.stdout.write(s + '\n'); appendFileSync(LOG, s + '\n'); };

const cfgText = readFileSync(join(homedir(), '.codex', 'config.toml'), 'utf8');
const TOKEN = cfgText.match(/experimental_bearer_token\s*=\s*"([^"]+)"/)[1];
const BASE = cfgText.match(/base_url\s*=\s*"([^"]+)"/)[1].replace(/\/+$/, '');

const MODEL = 'gpt-6-astra';
const TRIALS = Number(process.argv[2] || 4);
// 用真实规模的 prompt（约 2.8KB，和子代理那次失败的一致），不是玩具 prompt
const PROMPT = '请写一段 200 字左右的说明，解释为什么日志清理脚本需要 -DryRun 开关。';

async function call(effort, timeoutMs) {
  const body = {
    model: MODEL,
    messages: [{ role: 'user', content: PROMPT }],
    max_tokens: 600,
  };
  if (effort !== null) body.reasoning_effort = effort;

  const t0 = Date.now();
  try {
    const r = await fetch(`${BASE}/chat/completions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${TOKEN}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs),
    });
    const text = await r.text();
    const ms = Date.now() - t0;
    if (!r.ok) return { ok: false, ms, kind: `HTTP ${r.status}`, detail: text.slice(0, 150) };
    const j = JSON.parse(text);
    const reply = j.choices?.[0]?.message?.content ?? '';
    return { ok: !!reply.trim(), ms, kind: reply.trim() ? 'OK' : 'EMPTY', toc: j.usage?.completion_tokens };
  } catch (e) {
    const ms = Date.now() - t0;
    const kind = e?.name === 'TimeoutError' || e?.name === 'AbortError' ? `HANG>${timeoutMs}ms` : e?.name || 'Error';
    return { ok: false, ms, kind, detail: String(e?.message || e).slice(0, 150) };
  }
}

const EFFORTS = [null, 'low', 'high', 'max'];
const summary = [];

for (const eff of EFFORTS) {
  log(`\n### reasoning_effort = ${eff === null ? '(不发送)' : JSON.stringify(eff)}  × ${TRIALS}`);
  const times = [];
  let hangs = 0;
  for (let i = 1; i <= TRIALS; i++) {
    // 关键：给 45s 硬超时，这样挂起能被观测到而不是无限等
    const r = await call(eff, 45000);
    log(`  #${i} ${r.ok ? 'OK  ' : 'FAIL'} ${String(r.ms).padStart(6)}ms  ${r.kind}${r.toc ? `  out_tokens=${r.toc}` : ''}${r.detail ? '  ' + r.detail.replace(/\s+/g, ' ') : ''}`);
    if (r.ok) times.push(r.ms);
    if (String(r.kind).startsWith('HANG')) hangs++;
  }
  const s = times.length ? `成功 ${times.length}/${TRIALS}  耗时 min=${Math.min(...times)} avg=${Math.round(times.reduce((a, b) => a + b, 0) / times.length)} max=${Math.max(...times)}` : '全部失败';
  log(`  → ${s}   挂起 ${hangs} 次`);
  summary.push({ effort: eff === null ? '(none)' : eff, ok: times.length, trials: TRIALS, hangs });
}

log(`\n### 结论表`);
log(`effort        成功/总数   挂起`);
for (const s of summary) log(`${String(s.effort).padEnd(12)}  ${s.ok}/${s.trials}        ${s.hangs}`);
