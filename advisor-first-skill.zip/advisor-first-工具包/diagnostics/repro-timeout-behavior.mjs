#!/usr/bin/env node
/**
 * 两个假设的定向验证：
 *
 * H1: 真实失败配置 = effort:"max" + max_tokens:8000 + system 消息（非流式）→ 极长或挂起
 * H2: AbortSignal.timeout() 在这种"服务端发完头就沉默"的场景下【不生效】
 *     —— 这解释了为什么进程挂了 7 分钟，而我设的是 300s 超时
 *
 * H2 的验证方法：故意不设任何超时地看 abort 是否在 5s 时打断请求。
 */
import { readFileSync, appendFileSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';

const LOG = 'C:\\Users\\zzx123\\.local\\bin\\_advisor_repro.log';
writeFileSync(LOG, `=== repro ${new Date().toISOString()} ===\n`);
const log = (s) => { process.stdout.write(s + '\n'); appendFileSync(LOG, s + '\n'); };

const cfg = readFileSync(join(homedir(), '.codex', 'config.toml'), 'utf8');
const TOKEN = cfg.match(/experimental_bearer_token\s*=\s*"([^"]+)"/)[1];
const BASE = cfg.match(/base_url\s*=\s*"([^"]+)"/)[1].replace(/\/+$/, '');

const SYSTEM = [
  '你是一位资深技术顾问，负责在动手之前给出方案。',
  '要求：直接给可执行的结论，不要客套，不要复述问题。',
  '如果信息不足，明确列出你需要的关键信息，但仍要先给出基于现有信息的最佳方案。',
  '对不确定的地方必须显式标注"不确定"，禁止编造事实、路径、命令或 API。',
].join('\n');

const PROMPT = '请写一段 200 字左右的说明，解释为什么日志清理脚本需要 -DryRun 开关。';

// ---------- H2: AbortSignal.timeout 是否真的生效 ----------
log('### H2: AbortSignal.timeout(5000) 能否打断一个真实请求？');
{
  const t0 = Date.now();
  try {
    const r = await fetch(`${BASE}/chat/completions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${TOKEN}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: 'gpt-6-astra', messages: [{ role: 'user', content: PROMPT }], max_tokens: 600, stream: true }),
      signal: AbortSignal.timeout(5000),   // 故意设 5s，正常 TTFT 1.6s，总时长 8-34s
    });
    let bytes = 0;
    for await (const c of r.body) bytes += c.length;
    log(`  未被打断：流读完了，${bytes} bytes，${Date.now() - t0}ms`);
    log(`  → 说明 5s 超时【没有】在读取中途生效（因为总时长 > 5s 却读完了）`);
  } catch (e) {
    log(`  被中断：${e.name} @ ${Date.now() - t0}ms`);
  }
}

// ---------- H1: 真实失败配置 ----------
log('\n### H1: 非流式 + effort:"max" + max_tokens:8000 + system（真实的失败配置）');
for (let i = 1; i <= 3; i++) {
  const t0 = Date.now();
  try {
    const r = await fetch(`${BASE}/chat/completions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${TOKEN}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'gpt-6-astra',
        messages: [{ role: 'system', content: SYSTEM }, { role: 'user', content: PROMPT }],
        reasoning_effort: 'max',
        max_tokens: 8000,
      }),
      signal: AbortSignal.timeout(120000),
    });
    const text = await r.text();
    const j = JSON.parse(text);
    const reply = j.choices?.[0]?.message?.content ?? '';
    log(`  #${i} OK  ${Date.now() - t0}ms  out_tokens=${j.usage?.completion_tokens}  reply_len=${reply.length}`);
  } catch (e) {
    const kind = e?.name === 'TimeoutError' || e?.name === 'AbortError' ? 'HANG_ABORTED' : e.name;
    log(`  #${i} FAIL ${kind}  ${Date.now() - t0}ms`);
  }
}

log('\n### 对照：同样的配置但改成流式');
for (let i = 1; i <= 2; i++) {
  const t0 = Date.now();
  let ttft = null;
  try {
    const r = await fetch(`${BASE}/chat/completions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${TOKEN}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'gpt-6-astra',
        messages: [{ role: 'system', content: SYSTEM }, { role: 'user', content: PROMPT }],
        reasoning_effort: 'max',
        max_tokens: 8000,
        stream: true,
      }),
      signal: AbortSignal.timeout(120000),
    });
    let buf = '';
    for await (const c of r.body) {
      buf += Buffer.from(c).toString('utf8');
      if (ttft === null && /"content"\s*:\s*"[^"]/.test(buf)) ttft = Date.now() - t0;
      if (buf.includes('[DONE]')) break;
    }
    log(`  #${i} OK  total=${Date.now() - t0}ms  ttft=${ttft}ms  bytes=${buf.length}`);
  } catch (e) {
    log(`  #${i} FAIL ${e.name}  ${Date.now() - t0}ms  ttft=${ttft}`);
  }
}
