#!/usr/bin/env node
/**
 * 验证新版 ask-advisor.mjs 的三重看门狗是否真的能中断两类挂起：
 *   T1: 建连阶段挂起（服务端不回响应头）—— 子代理实测 AbortSignal.timeout 在此失效
 *   T2: 响应中途静默（发完头就停）
 *
 * 做法：用本地假服务器精确模拟这两种病态行为，指向被测的看门狗逻辑。
 * 这是"看着它失败过"——先证明看门狗在病态服务器前会触发。
 */
import http from 'node:http';

const results = [];
const log = (s) => { process.stdout.write(s + '\n'); };

/** 起一个病态服务器 */
function makeServer(behavior) {
  return http.createServer((req, res) => {
    if (behavior === 'neverRespond') {
      // T1: 收下请求，永远不回任何字节
      return;
    }
    if (behavior === 'headersThenSilence') {
      // T2: 立刻回到头，然后永远沉默
      res.writeHead(200, { 'Content-Type': 'text/event-stream' });
      res.write(': keepalive\n\n');
      return;
    }
    if (behavior === 'slowThenOk') {
      // 对照：慢但正常，看门狗不应误杀
      res.writeHead(200, { 'Content-Type': 'text/event-stream' });
      res.write('data: {"choices":[{"delta":{"content":"OK"}}]}\n\n');
      res.write('data: [DONE]\n\n');
      return res.end();
    }
  });
}

/**
 * 复刻 ask-advisor.mjs 的看门狗逻辑（保持同步，改逻辑必须同时改这里）
 */
async function watchdawgFetch(url, { ttftMs, idleMs, totalMs }) {
  const ac = new AbortController();
  let abortReason = null;
  const t0 = Date.now();
  let ttftTimer = setTimeout(() => { if (abortReason === null) { abortReason = `首字节超过 ${ttftMs}ms 未到达`; ac.abort(); } }, ttftMs);
  let idleTimer = null;
  const totalTimer = setTimeout(() => { if (abortReason === null) { abortReason = `总时长超过 ${totalMs}ms`; ac.abort(); } }, totalMs);
  const clearAll = () => { clearTimeout(ttftTimer); if (idleTimer) clearTimeout(idleTimer); clearTimeout(totalTimer); };

  try {
    const res = await fetch(url, { signal: ac.signal });
    if (!res.ok) { clearAll(); throw new Error(`HTTP ${res.status}`); }
    const ttft = Date.now() - t0;
    clearTimeout(ttftTimer); ttftTimer = null;
    const bumpIdle = () => { if (idleTimer) clearTimeout(idleTimer); idleTimer = setTimeout(() => { if (abortReason === null) { abortReason = `空闲超过 ${idleMs}ms 无新数据`; ac.abort(); } }, idleMs); };
    bumpIdle();
    let buf = '';
    for await (const c of res.body) { bumpIdle(); buf += Buffer.from(c).toString('utf8'); }
    clearAll();
    return { ok: true, ttft, ms: Date.now() - t0, buf };
  } catch (e) {
    clearAll();
    return { ok: false, ms: Date.now() - t0, reason: abortReason || `${e.name}: ${e.message}` };
  }
}

const scenarios = [
  { name: 'T1 建连后永不回响应头', behavior: 'neverRespond',        expectAbort: true,  limitMs: 25000 },
  { name: 'T2 回了头随后沉默',     behavior: 'headersThenSilence',  expectAbort: true,  limitMs: 25000 },
  { name: '对照 慢但正常',         behavior: 'slowThenOk',          expectAbort: false, limitMs: 25000 },
];

for (const s of scenarios) {
  const server = makeServer(s.behavior);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const port = server.address().port;
  const url = `http://127.0.0.1:${port}/v1/chat/completions`;

  const t0 = Date.now();
  const r = await watchdawgFetch(url, { ttftMs: 5000, idleMs: 5000, totalMs: 20000 });
  const wall = Date.now() - t0;

  const aborted = !r.ok;
  const verdict = aborted === s.expectAbort ? 'PASS' : 'FAIL';
  log(`${verdict}  ${s.name}`);
  log(`      期望中断=${s.expectAbort}  实际=${aborted}  墙钟=${wall}ms  上限=${s.limitMs}ms  ${r.ok ? `收到 ${r.buf.length}B` : `原因: ${r.reason}`}`);
  if (s.expectAbort && wall > s.limitMs) log(`      ⚠️ 超时未在预期时间内触发！`);
  results.push({ name: s.name, verdict, wall, aborted, reason: r.reason });

  server.close();
  await new Promise((r2) => setTimeout(r2, 200));
}

log('\n=== 汇总 ===');
const failed = results.filter((r) => r.verdict !== 'PASS');
log(failed.length === 0 ? `全部通过（${results.length}/${results.length}）—— 三重看门狗确实能中断两类挂起` : `有 ${failed.length} 项未通过：${failed.map((f) => f.name).join(', ')}`);
process.exitCode = failed.length === 0 ? 0 : 1;
