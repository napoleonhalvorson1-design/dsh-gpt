#!/usr/bin/env node
/**
 * 诊断 Modelflare 中转的真实失败模式。
 * 测三件事：
 *   A) 非流式调用：端到端耗时分布、失败率、失败形态
 *   B) 流式调用：首个 token 到达时间（TTFT）—— 决定超时该设多少的关键指标
 *   C) 多模型：哪个模型最稳
 *
 * 用法：node advisor-diagnose.mjs [每项次数]
 */
import { readFileSync, existsSync, appendFileSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';

const LOG = 'C:\\Users\\zzx123\\.local\\bin\\_advisor_diag.log';
writeFileSync(LOG, `=== advisor diagnosis ${new Date().toISOString()} ===\n`);

function log(s) {
  process.stdout.write(s + '\n');
  appendFileSync(LOG, s + '\n');
}

const cfgText = readFileSync(join(homedir(), '.codex', 'config.toml'), 'utf8');
const TOKEN = cfgText.match(/experimental_bearer_token\s*=\s*"([^"]+)"/)[1];
const BASE = cfgText.match(/base_url\s*=\s*"([^"]+)"/)[1].replace(/\/+$/, '');
log(`BASE=${BASE}`);

const N = Number(process.argv[2] || 5);
const PROMPT = '只回答一个词：OK';

/** payload 大小对耗时的影响 —— 测小 payload，隔离网络因素 */
function smallBody(model, stream) {
  return JSON.stringify({
    model,
    messages: [{ role: 'user', content: PROMPT }],
    max_tokens: 16,
    ...(stream ? { stream: true } : {}),
  });
}

/** A) 非流式：端到端耗时 + 失败形态 */
async function probeNonStream(model, timeoutMs = 90000) {
  const t0 = Date.now();
  try {
    const r = await fetch(`${BASE}/chat/completions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${TOKEN}`, 'Content-Type': 'application/json' },
      body: smallBody(model, false),
      signal: AbortSignal.timeout(timeoutMs),
    });
    const text = await r.text();
    const ms = Date.now() - t0;
    if (!r.ok) return { ok: false, ms, kind: `HTTP ${r.status}`, detail: text.slice(0, 200) };
    const j = JSON.parse(text);
    const reply = j.choices?.[0]?.message?.content ?? '';
    return { ok: !!reply.trim(), ms, kind: reply.trim() ? 'OK' : 'EMPTY', detail: '' };
  } catch (e) {
    const ms = Date.now() - t0;
    const name = e?.name === 'TimeoutError' ? `TIMEOUT>${timeoutMs}ms` : e?.name || 'Error';
    return { ok: false, ms, kind: name, detail: String(e?.message || e).slice(0, 200) };
  }
}

/** B) 流式：测 TTFT —— 关键指标 */
async function probeStream(model, timeoutMs = 90000) {
  const t0 = Date.now();
  let ttft = null;
  try {
    const r = await fetch(`${BASE}/chat/completions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${TOKEN}`, 'Content-Type': 'application/json' },
      body: smallBody(model, true),
      signal: AbortSignal.timeout(timeoutMs),
    });
    if (!r.ok) {
      const text = await r.text();
      return { ok: false, ms: Date.now() - t0, ttft: null, kind: `HTTP ${r.status}`, detail: text.slice(0, 200) };
    }
    let buf = '';
    for await (const chunk of r.body) {
      buf += Buffer.from(chunk).toString('utf8');
      if (ttft === null && /"content"\s*:\s*"[^"]/.test(buf)) ttft = Date.now() - t0;
      if (buf.includes('[DONE]')) break;
    }
    return { ok: ttft !== null, ms: Date.now() - t0, ttft, kind: ttft !== null ? 'OK' : 'NO_CONTENT', detail: '' };
  } catch (e) {
    const name = e?.name === 'TimeoutError' ? `TIMEOUT>${timeoutMs}ms` : e?.name || 'Error';
    return { ok: false, ms: Date.now() - t0, ttft, kind: name, detail: String(e?.message || e).slice(0, 200) };
  }
}

function stats(xs) {
  if (!xs.length) return 'n/a';
  const s = [...xs].sort((a, b) => a - b);
  const p = (q) => s[Math.min(s.length - 1, Math.floor(q * s.length))];
  return `min=${s[0]} p50=${p(0.5)} p90=${p(0.9)} max=${s[s.length - 1]}`;
}

const results = [];

log(`\n### A) 非流式 × ${N}（model=gpt-6-astra, max_tokens=16）`);
const aTimes = [], aFails = [];
for (let i = 1; i <= N; i++) {
  const r = await probeNonStream('gpt-6-astra');
  log(`  #${i} ${r.ok ? 'OK ' : 'FAIL'} ${String(r.ms).padStart(6)}ms  ${r.kind}${r.detail ? '  ' + r.detail.replace(/\s+/g, ' ') : ''}`);
  if (r.ok) aTimes.push(r.ms); else aFails.push(r);
  results.push({ probe: 'nonstream-astra', ...r });
}

log(`\n### B) 流式 × ${N}（测 TTFT）`);
const bTtft = [], bFails = [];
for (let i = 1; i <= N; i++) {
  const r = await probeStream('gpt-6-astra');
  log(`  #${i} ${r.ok ? 'OK ' : 'FAIL'} total=${String(r.ms).padStart(6)}ms ttft=${r.ttft === null ? '   -' : String(r.ttft).padStart(6)}ms  ${r.kind}`);
  if (r.ok) bTtft.push(r.ttft); else bFails.push(r);
  results.push({ probe: 'stream-astra', ...r });
}

log(`\n### C) 多模型各 2 次（非流式）`);
const models = ['gpt-6-astra', 'gpt-6-sol', 'gpt-6-luna', 'gpt-6.1-sol'];
for (const m of models) {
  const row = [];
  for (let i = 0; i < 2; i++) {
    const r = await probeNonStream(m, 60000);
    row.push(`${r.ok ? 'OK' : 'FAIL'} ${r.ms}ms ${r.ok ? '' : r.kind}`);
    results.push({ probe: `model-${m}`, ...r });
  }
  log(`  ${m.padEnd(14)} ${row.join('  |  ')}`);
}

log(`\n### 汇总`);
log(`非流式 成功 ${aTimes.length}/${N}  耗时 ${stats(aTimes)}`);
log(`  失败形态: ${aFails.length ? aFails.map((f) => `${f.kind}(${f.ms}ms)`).join(', ') : '无'}`);
log(`流式   成功 ${bTtft.length}/${N}  TTFT ${stats(bTtft)}`);
log(`  失败形态: ${bFails.length ? bFails.map((f) => `${f.kind}(total ${f.ms}ms)`).join(', ') : '无'}`);
log(`\n完整 JSON 结果已写 ${LOG}`);

// 便于机器读取
appendFileSync(LOG, '\n--- RESULTS JSON ---\n' + JSON.stringify(results, null, 2));
