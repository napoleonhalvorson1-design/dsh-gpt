// run-tests-deepseek.mjs — DeepSeek Harness 的回归测试
//
// 基于 advisor-first 的测试框架，验证所有可靠性机制在 DeepSeek 场景下仍然有效。
//
// 用法：node run-tests-deepseek.mjs
//       $env:SKIP_NETWORK=1; node run-tests-deepseek.mjs   只跑离线部分
// 退出码：0 = 全部通过；1 = 有失败

import http from 'node:http';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdtempSync, writeFileSync, readFileSync } from 'node:fs';
import { tmpdir, homedir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const DEEPSEEK = join(HERE, 'ask-deepseek.mjs');
const results = [];
const log = (s) => process.stdout.write(s + '\n');

function record(name, pass, detail) {
  results.push({ name, pass, detail });
  log(`${pass ? 'PASS' : 'FAIL'}  ${name}`);
  if (detail) log(`      ${detail}`);
}

// ─────────────────────────────────────────────────────────────
// T1–T3：看门狗能否中断病态连接
// ─────────────────────────────────────────────────────────────

function makeServer(behavior) {
  return http.createServer((req, res) => {
    if (behavior === 'neverRespond') return;
    if (behavior === 'headersThenSilence') {
      res.writeHead(200, { 'Content-Type': 'text/event-stream' });
      res.write(': keepalive\n\n');
      return;
    }
    if (behavior === 'slowThenOk') {
      res.writeHead(200, { 'Content-Type': 'text/event-stream' });
      res.write('data: {"choices":[{"delta":{"content":"OK"}}]}\n\n');
      res.write('data: [DONE]\n\n');
      return res.end();
    }
  });
}

/** 复刻 ask-deepseek.mjs 的看门狗语义 */
async function watchdawgFetch(url, { ttftMs, idleMs, totalMs }) {
  const ac = new AbortController();
  let abortReason = null;
  const t0 = Date.now();
  let ttftTimer = setTimeout(() => { if (abortReason === null) { abortReason = `首字节超过 ${ttftMs}ms 未到达`; ac.abort(); } }, ttftMs);
  let idleTimer = null;
  const totalTimer = setTimeout(() => { if (abortReason === null) { abortReason = `总时长超过 ${totalMs}ms`; ac.abort(); } }, totalMs);
  const clearAll = () => { clearTimeout(ttftTimer); if (idleTimer) { clearInterval(idleTimer); idleTimer = null; } clearTimeout(totalTimer); };
  try {
    const res = await fetch(url, { signal: ac.signal });
    if (!res.ok) { clearAll(); throw new Error(`HTTP ${res.status}`); }
    const ttft = Date.now() - t0;
    clearTimeout(ttftTimer); ttftTimer = null;
    let lastContentAt = Date.now();
    let lastByteAt = Date.now();
    idleTimer = setInterval(() => {
      if (abortReason !== null) return;
      const silent = Date.now() - lastContentAt;
      if (silent > idleMs) {
        abortReason = `正文停止增长 ${silent}ms`;
        clearInterval(idleTimer); idleTimer = null;
        ac.abort();
      }
    }, 1000);
    let buf = '';
    for await (const c of res.body) {
      lastByteAt = Date.now();
      buf += Buffer.from(c).toString('utf8');
      if (/"content"\s*:\s*"[^"]/.test(buf)) lastContentAt = Date.now();
    }
    clearAll();
    return { ok: true, ttft, ms: Date.now() - t0, buf };
  } catch (e) {
    clearAll();
    return { ok: false, ms: Date.now() - t0, reason: abortReason || `${e.name}: ${e.message}` };
  }
}

const scenarios = [
  { name: 'T1 建连后永不回响应头 → 必须中断', behavior: 'neverRespond', expectAbort: true, limitMs: 20000 },
  { name: 'T2 回了头随后沉默 → 必须中断', behavior: 'headersThenSilence', expectAbort: true, limitMs: 20000 },
  { name: 'T3 对照：慢但正常 → 不应误杀', behavior: 'slowThenOk', expectAbort: false, limitMs: 20000 },
];

for (const s of scenarios) {
  const server = makeServer(s.behavior);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const url = `http://127.0.0.1:${server.address().port}/v1/chat/completions`;
  const r = await watchdawgFetch(url, { ttftMs: 5000, idleMs: 5000, totalMs: 15000 });
  const aborted = !r.ok;
  const timedOutPromptly = !s.expectAbort || r.ms <= s.limitMs;
  record(s.name, aborted === s.expectAbort && timedOutPromptly,
    `期望中断=${s.expectAbort} 实际=${aborted} 墙钟=${r.ms}ms ${r.ok ? `收到 ${r.buf.length}B` : `原因: ${r.reason}`}`);
  server.close();
  await new Promise((r2) => setTimeout(r2, 150));
}

// ─────────────────────────────────────────────────────────────
// T4–T7：本地参数校验类失败
// ─────────────────────────────────────────────────────────────
function runDeepSeek(args, opts = {}) {
  const r = spawnSync(process.execPath, [DEEPSEEK, ...args], {
    encoding: 'utf8', timeout: opts.timeout ?? 120000, ...opts,
  });
  return { code: r.status, out: r.stdout ?? '', err: r.stderr ?? '' };
}

{
  const r = runDeepSeek([]);
  record('T4 空提示词 → exit=1 且提示用法', r.code === 1 && /没有提示词/.test(r.err), `exit=${r.code}`);
}
{
  const r = runDeepSeek(['--help']);
  record('T5 --help → exit=0 且不继续执行', r.code === 0 && /用法/.test(r.out), `exit=${r.code} stdout=${r.out.length}B`);
}
{
  const r = runDeepSeek(['--prompt-file', 'C:\\definitely\\not\\here\\nope.md']);
  record('T6 提示词文件不存在 → exit=1', r.code === 1 && /不存在/.test(r.err), `exit=${r.code}`);
}
{
  // 假 key 必须快速失败，且把 HTTP 状态打出来
  const r = runDeepSeek(['--attempts', '1', 'hi'], {
    env: {
      ...process.env,
      DEEPSEEK_API_KEY: 'sk-deliberately-wrong',
      DEEPSEEK_BASE_URL: 'https://api.deepseek.com/v1'
    }
  });
  record('T7 错误 key → exit=1 且 stderr 含 HTTP 状态', r.code === 1 && /HTTP 40\d/.test(r.err),
    `exit=${r.code} stderr=${r.err.length}B`);
}

// ─────────────────────────────────────────────────────────────
// T8：联网冒烟（可选）—— 只有真正拿到正文才算通过
// ─────────────────────────────────────────────────────────────
if (process.env.SKIP_NETWORK !== '1') {
  const hasKey = process.env.DEEPSEEK_API_KEY || existsSync(join(homedir(), '.codex', 'config.toml'));
  if (hasKey) {
    const r = runDeepSeek(['--quiet', '只回复两个字：在吗'], { timeout: 150000 });
    const ok = r.code === 0 && r.out.trim().length > 0;
    record('T8 联网冒烟：短问题必须拿到非空正文', ok, `exit=${r.code} 正文=${r.out.trim().length}字`);
  } else {
    log('SKIP  T8 联网冒烟（无 DEEPSEEK_API_KEY 或 ~/.codex/config.toml）');
  }
} else {
  log('SKIP  T8 联网冒烟（SKIP_NETWORK=1）');
}

// ─────────────────────────────────────────────────────────────
const failed = results.filter((x) => !x.pass);
log('');
log('='.repeat(60));
log(failed.length === 0
  ? `全部通过：${results.length}/${results.length + (process.env.SKIP_NETWORK === '1' ? 1 : 0)}`
  : `失败 ${failed.length} 项：\n  - ` + failed.map((f) => `${f.name}（${f.detail}）`).join('\n  - '));
process.exitCode = failed.length === 0 ? 0 : 1;
