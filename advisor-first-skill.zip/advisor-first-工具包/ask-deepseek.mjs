#!/usr/bin/env node
/**
 * ask-deepseek.mjs — 调用 DeepSeek 模型获取技术建议和方案
 *
 * ── 设计原则（继承自 advisor-first 的实测经验）─────────────────────
 *   1. **默认流式**：TTFT ~1-2s，能立刻判断服务端是否在干活
 *   2. **三重看门狗**：
 *        · 首字节超时 30s
 *        · 正文停止增长超时 60s（每 1 秒轮询检查）
 *        · 单次尝试总时长硬上限 120s
 *   3. **有界重试 + 退避**：默认每模型 3 次尝试，退避 1.5s/3s
 *   4. **模型回退链**：主模型失败自动切到备用模型
 *   5. **stderr 活性输出**：进度可见，不再是黑盒
 *   6. **进程级兜底**：未捕获异常一律 exit=1
 *
 * 用法：
 *   node ask-deepseek.mjs "你的问题"
 *   node ask-deepseek.mjs --prompt-file p.md
 *   node ask-deepseek.mjs --model deepseek-chat "..."
 *   node ask-deepseek.mjs --list | --json | --help
 *   echo "..." | node ask-deepseek.mjs -
 *
 * 凭据：DEEPSEEK_API_KEY / DEEPSEEK_BASE_URL，或读 ~/.codex/config.toml
 * 退出码：0 成功（正文→stdout）；1 失败（原因→stderr）
 */
import { readFileSync, existsSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { StringDecoder } from 'node:string_decoder';

const CODEX_CONFIG = join(homedir(), '.codex', 'config.toml');
const DEFAULT_TTFT_MS = 30000;    // 首字节上限
const DEFAULT_IDLE_MS = 45000;    // 正文停止增长的上限
const DEFAULT_TOTAL_MS = 120000;  // 单次尝试硬上限
const DEFAULT_ATTEMPTS = 3;
// DeepSeek 实测可用模型（2024）：deepseek-flash, deepseek-v4-pro
const FALLBACK_CHAIN = ['deepseek-flash'];

function parseArgs(argv) {
  const o = { positional: [], json: false, list: false, help: false, quiet: false,
              model: null, effort: null, promptFile: null, attempts: null,
              ttft: null, idle: null, total: null, out: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--json') o.json = true;
    else if (a === '--list') o.list = true;
    else if (a === '--quiet') o.quiet = true;
    else if (a === '--help' || a === '-h') o.help = true;
    else if (a === '--model') o.model = argv[++i];
    else if (a === '--effort') o.effort = argv[++i];
    else if (a === '--prompt-file') o.promptFile = argv[++i];
    else if (a === '--attempts') o.attempts = Number(argv[++i]);
    else if (a === '--ttft-ms') o.ttft = Number(argv[++i]);
    else if (a === '--idle-ms') o.idle = Number(argv[++i]);
    else if (a === '--total-ms') o.total = Number(argv[++i]);
    else if (a === '--out') o.out = argv[++i];
    else o.positional.push(a);
  }
  return o;
}

const USAGE = `用法：
  node ask-deepseek.mjs "你的问题"
  node ask-deepseek.mjs --prompt-file 提示词.md
  node ask-deepseek.mjs --model deepseek-flash "问题"
  node ask-deepseek.mjs --list                列出可用模型
选项：
  --model <id>       默认 deepseek-v4-pro（失败自动回退 ${FALLBACK_CHAIN.join(' → ')}）
  --effort <e>       low | high | max（默认 max，实测两模型都支持）
  --prompt-file <f>  从文件读提示词
  --out <f>          把正文同时写一份到文件
  --json             输出含 usage 的 JSON
  --quiet            不往 stderr 写进度
  --attempts <n>     每个模型尝试次数，默认 ${DEFAULT_ATTEMPTS}
  --ttft-ms <n>      首字节超时，默认 ${DEFAULT_TTFT_MS}
  --idle-ms <n>      数据块间空闲超时，默认 ${DEFAULT_IDLE_MS}
  --total-ms <n>     总时长硬上限，默认 ${DEFAULT_TOTAL_MS}
`;

/**
 * 从 ~/.codex/config.toml 读 **当前生效的 model_providers 块**。
 *
 * ⚠️ 不能只匹配文件里第一个 base_url / experimental_bearer_token：
 * 该文件可以同时存在多个 provider 块（本机就有 [model_providers.fox] 和
 * [model_providers.custom]），谁在前谁在后取决于文件结构，随便抓一个会拿错凭据。
 * 这里只认 `model_provider = "<name>"` 指向的那个块。
 */
function readCodexProvider() {
  const r = { token: null, baseUrl: null, provider: null };
  if (!existsSync(CODEX_CONFIG)) return r;
  let t;
  try { t = readFileSync(CODEX_CONFIG, 'utf8'); } catch { return r; }

  const active = t.match(/^\s*model_provider\s*=\s*"([^"]+)"/m);
  if (!active) return r;
  r.provider = active[1];

  // 截出 [model_providers.<active>] 这一段（到下一个 [ 表头为止）
  const esc = active[1].replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const sec = t.match(new RegExp(`\\[model_providers\\.${esc}\\]([\\s\\S]*?)(?=\\n\\[|$)`));
  if (!sec) return r;
  const body = sec[1];

  const tok = body.match(/experimental_bearer_token\s*=\s*"([^"]+)"/);
  if (tok) r.token = tok[1];
  const base = body.match(/base_url\s*=\s*"([^"]+)"/);
  if (base) r.baseUrl = base[1];
  return r;
}

/**
 * 从 DSH 的凭据文件读 DeepSeek key。
 * 本机真实存在：~/.dsh-beta/.credentials.yaml 里 refs.DEEPSEEK_API_KEY。
 * 加这一层的理由：这个 key 本来就在机器上，工具却要用户「显式设置环境变量」，
 * 属于把麻烦推给用户。YAML 结构固定（refs: 下的一层 key: value），
 * 因此用最小解析即可，不引入 js-yaml 依赖。
 */
function readDshCredentials() {
  const p = join(homedir(), '.dsh-beta', '.credentials.yaml');
  if (!existsSync(p)) return null;
  let t;
  try { t = readFileSync(p, 'utf8'); } catch { return null; }
  // 只在 refs: 段落内找，避免误抓 payload 里的同名字段
  const refs = t.match(/^refs:\s*\n([\s\S]*?)(?=\n\S|$)/m);
  if (!refs) return null;
  const m = refs[1].match(/^\s*DEEPSEEK_API_KEY:\s*(\S+)\s*$/m);
  return m ? m[1] : null;
}

async function readStdin() {
  const chunks = [];
  for await (const c of process.stdin) chunks.push(c);
  return Buffer.concat(chunks).toString('utf8');
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

class AttemptError extends Error {
  constructor(msg, retryable = true) {
    super(msg);
    this.retryable = retryable;
  }
}

/**
 * 单次流式调用，带三重看门狗。
 * 返回 { reply, usage, ttftMs, totalMs }。
 */
async function streamOnce({ base, token, model, system, prompt, effort, ttftMs, idleMs, totalMs, onProgress }) {
  const ac = new AbortController();
  let abortReason = null;
  const t0 = Date.now();

  let ttftTimer = setTimeout(() => {
    if (abortReason === null) { abortReason = `首字节超过 ${ttftMs}ms 未到达`; ac.abort(); }
  }, ttftMs);
  let idleTimer = null;
  const totalTimer = setTimeout(() => {
    if (abortReason === null) { abortReason = `总时长超过 ${totalMs}ms`; ac.abort(); }
  }, totalMs);

  const clearAll = () => {
    clearTimeout(ttftTimer);
    if (idleTimer) { clearInterval(idleTimer); idleTimer = null; }
    clearTimeout(totalTimer);
  };

  const body = {
    model,
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: prompt },
    ],
    reasoning_effort: effort,
    max_tokens: 8000,
    stream: true,
  };

  try {
    const res = await fetch(`${base}/chat/completions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: ac.signal,
    });

    if (!res.ok) {
      const text = await res.text();
      clearAll();
      const retryable = res.status >= 500 || res.status === 429;
      throw new AttemptError(`HTTP ${res.status} ${text.slice(0, 300)}`, retryable);
    }

    // 首字节到了 —— 关掉 TTFT 计时，改用「有效内容」空闲看门狗
    const ttft = Date.now() - t0;
    clearTimeout(ttftTimer);
    ttftTimer = null;

    let buf = '';
    let reply = '';
    let usage = null;
    let emitted = 0;
    let lastByteAt = Date.now();
    let lastContentAt = Date.now();
    const decoder = new StringDecoder('utf8');  // 跨 chunk 拼多字节字符，见下方说明

    /**
     * 看门狗：每 1 秒检查一次「正文是否还在增长」
     * 判据必须是**正文增长**，不是「收到字节」
     */
    idleTimer = setInterval(() => {
      if (abortReason !== null) return;
      const silentMs = Date.now() - lastContentAt;
      if (silentMs > idleMs) {
        const sinceByte = Date.now() - lastByteAt;
        const onlyHeartbeat = sinceByte < silentMs / 2;
        abortReason = `正文停止增长 ${silentMs}ms（上限 ${idleMs}ms）` +
          (onlyHeartbeat ? `，但 ${sinceByte}ms 前仍有字节到达 = 只有保活心跳` : '，且无任何字节到达');
        clearInterval(idleTimer);
        idleTimer = null;
        ac.abort();
      }
    }, 1000);

    onProgress?.(`首字节 ${ttft}ms，开始接收…`);

    for await (const chunk of res.body) {
      lastByteAt = Date.now();
      // ⚠️ 必须用 StringDecoder，不能 Buffer.from(chunk).toString('utf8')。
      // 后者对每个 chunk 独立解码：一个中文字符占 3 字节，被 TCP 分片切开时
      // 前半截解码失败就变成 U+FFFD（实测「计算阶乘」的"计"字被吃成 \uFFFD，
      // 而且这个损坏会一路写进 --out 文件，不是显示问题）。
      buf += decoder.write(chunk);

      let nl;
      while ((nl = buf.indexOf('\n')) !== -1) {
        const line = buf.slice(0, nl).trim();
        buf = buf.slice(nl + 1);
        if (!line.startsWith('data:')) continue;
        const data = line.slice(5).trim();
        if (data === '[DONE]') continue;
        let j;
        try { j = JSON.parse(data); } catch { continue; }
        const delta = j.choices?.[0]?.delta?.content;
        if (typeof delta === 'string' && delta) {
          reply += delta;
          emitted++;
          lastContentAt = Date.now();
          if (emitted % 60 === 0) onProgress?.(`已接收约 ${reply.length} 字…`);
        }
        if (j.usage) usage = j.usage;
      }
    }

    clearAll();
    if (!reply.trim()) throw new AttemptError('流结束了但正文为空', true);
    return { reply, usage, ttftMs: ttft, totalMs: Date.now() - t0 };
  } catch (e) {
    clearAll();
    if (abortReason !== null) throw new AttemptError(`看门狗触发：${abortReason}`, true);
    if (e instanceof AttemptError) throw e;
    throw new AttemptError(`${e?.name || 'Error'}: ${e?.message || e}`, true);
  }
}

async function listModels(base, token) {
  const r = await fetch(`${base}/models`, { headers: { Authorization: `Bearer ${token}` } });
  if (!r.ok) throw new Error(`GET /models 失败 (${r.status}) ${(await r.text()).slice(0, 300)}`);
  const j = await r.json();
  return (j.data || []).map((m) => m.id).sort();
}

function fail(msg) {
  process.stderr.write(`ask-deepseek: ${msg}\n`);
  process.exitCode = 1;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) { process.stdout.write(USAGE); return; }

  const cfg = readCodexProvider();
  const base = (process.env.DEEPSEEK_BASE_URL || 'https://api.deepseek.com/v1').replace(/\/+$/, '');

  const effort = args.effort || process.env.DEEPSEEK_EFFORT || 'max';
  const primary = args.model || process.env.DEEPSEEK_MODEL || 'deepseek-v4-pro';
  const attempts = Math.max(1, args.attempts || DEFAULT_ATTEMPTS);
  const ttftMs = args.ttft || DEFAULT_TTFT_MS;
  const idleMs = args.idle || DEFAULT_IDLE_MS;
  const totalMs = args.total || DEFAULT_TOTAL_MS;

  const note = (s) => { if (!args.quiet) process.stderr.write(`[deepseek] ${s}\n`); };

  // ─────────────────────────────────────────────────────────────
  // 顺序很重要：**先解析参数与提示词，再检查凭据**。
  // 反例（本文件曾犯过）：把凭据检查提到最前，导致
  //   `ask-deepseek.mjs`（空提示词）和 `--prompt-file 不存在的文件`
  // 都报「必须设置 DEEPSEEK_API_KEY」，exit=1 虽对但原因全错，
  // 用户无法定位自己错在哪一步。参数类错误必须优先于环境类错误。
  // 例外：--list 不需要提示词，它的参数校验只有自己那条。
  // ─────────────────────────────────────────────────────────────
  let prompt = null;
  if (!args.list) {
    prompt = args.positional.join(' ').trim();
    if (args.promptFile) {
      if (!existsSync(args.promptFile)) return fail(`提示词文件不存在：${args.promptFile}`);
      prompt = readFileSync(args.promptFile, 'utf8');
    }
    if (!prompt || prompt === '-') {
      const piped = (await readStdin()).trim();
      if (piped) prompt = piped;
    }
    if (!prompt) return fail(`没有提示词\n${USAGE}`);
  }

  // ── 凭据解析：只允许「与端点匹配的凭据」──
  // 优先级：环境变量 → DSH 凭据文件 → codex 配置（仅当它也指向 DeepSeek）
  // 绝不把 A 家的令牌发去 B 家端点：那只会换来一个 401，
  // 白等一轮重试，还把真正的原因藏起来。
  let token = process.env.DEEPSEEK_API_KEY || null;
  let tokenFrom = token ? '环境变量 DEEPSEEK_API_KEY' : null;

  if (!token) {
    const fromFile = readDshCredentials();
    // 只有当 DSH 凭据文件里的 key 确实叫 DEEPSEEK_API_KEY 时才用——
    // 名字本身就是"它属于 DeepSeek"的声明，不存在张冠李戴。
    if (fromFile) { token = fromFile; tokenFrom = '~/.dsh-beta/.credentials.yaml'; }
  }

  if (!token) {
    const codexIsDeepSeek = cfg.baseUrl ? cfg.baseUrl.includes('api.deepseek.com') : false;
    if (cfg.token && codexIsDeepSeek) {
      token = cfg.token;
      tokenFrom = `~/.codex/config.toml [model_providers.${cfg.provider}]`;
    }
  }

  if (!token) {
    const hints = [];
    if (cfg.baseUrl && !cfg.baseUrl.includes('api.deepseek.com')) {
      hints.push(`~/.codex/config.toml 的当前 provider「${cfg.provider}」指向 ${cfg.baseUrl}（非 DeepSeek），其令牌不能用于本工具`);
    }
    hints.push('请任选一种方式提供 DeepSeek 凭据：');
    hints.push('  1) 设置环境变量：$env:DEEPSEEK_API_KEY = "sk-..."');
    hints.push('  2) 写入 ~/.dsh-beta/.credentials.yaml 的 refs.DEEPSEEK_API_KEY');
    hints.push('  3) 让 ~/.codex/config.toml 的当前 provider 指向 https://api.deepseek.com');
    hints.push(`当前端点：${base}`);
    return fail('找不到 DeepSeek API key\n  · ' + hints.join('\n  · '));
  }

  // list 需要凭据，放在凭据解析之后
  if (args.list) {
    try {
      process.stdout.write((await listModels(base, token)).join('\n') + '\n');
    } catch (e) { return fail(e.message); }
    return;
  }

  const system = [
    '你是一位资深技术顾问，负责在动手之前给出方案。',
    '要求：直接给可执行的结论，不要客套，不要复述问题。',
    '如果信息不足，明确列出你需要的关键信息，但仍要先给出基于现有信息的最佳方案。',
    '对不确定的地方必须显式标注"不确定"，禁止编造事实、路径、命令或 API。',
  ].join('\n');

  const chain = [primary, ...FALLBACK_CHAIN].filter((m, i, a) => a.indexOf(m) === i);
  const failures = [];
  let attemptNo = 0;
  const userSpecifiedModel = args.model || process.env.DEEPSEEK_MODEL;
  let usedFallback = false;

  // 透明化：凭据取自哪里必须可见，否则用户无法判断自己在用谁的身份
  note(`端點=${base} 凭据来源=${tokenFrom}`);

  for (let ci = 0; ci < chain.length; ci++) {
    const model = chain[ci];
    for (let i = 0; i < attempts; i++) {
      attemptNo++;
      note(`尝试 ${attemptNo}：model=${model}（TTFT≤${ttftMs} idle≤${idleMs} total≤${totalMs}）`);
      try {
        const r = await streamOnce({
          base, token, model, system, prompt, effort, ttftMs, idleMs, totalMs,
          onProgress: (s) => note(`  ${s}`),
        });
        note(`成功：model=${model} ttft=${r.ttftMs}ms total=${r.totalMs}ms${r.usage ? ` usage=${JSON.stringify(r.usage)}` : ''}`);

        // 检测是否使用了回退模型
        if (userSpecifiedModel && model !== userSpecifiedModel) {
          usedFallback = true;
          note(`警告：用户指定 ${userSpecifiedModel} 失败，实际使用 ${model}`);
        }

        if (args.out) {
          try { writeFileSync(args.out, r.reply); note(`正文已另存 ${args.out}`); }
          catch (e) { note(`写 --out 失败：${e.message}`); }
        }

        if (args.json) {
          process.stdout.write(JSON.stringify({
            model,
            requestedModel: userSpecifiedModel || primary,
            usedFallback,
            attempts: attemptNo,
            ...r
          }, null, 2) + '\n');
        } else {
          process.stdout.write(r.reply.trimEnd() + '\n');
        }

        // 用户明确指定模型但用了回退 → exit=1
        if (userSpecifiedModel && usedFallback) {
          return fail(`指定的模型 ${userSpecifiedModel} 不可用，虽然回退到 ${model} 成功了，但这不符合用户指定`);
        }
        return;
      } catch (e) {
        const msg = e?.message || String(e);
        failures.push(`${model} 第${i + 1}次: ${msg}`);
        note(`失败：${msg}`);
        if (e instanceof AttemptError && e.retryable === false) {
          note('该类错误不可重试，跳到下一个模型');
          break;
        }
        if (i < attempts - 1) await sleep(1500 * (i + 1));
      }
    }
    if (ci < chain.length - 1) note(`模型 ${model} 未成功，回退到 ${chain[ci + 1]}`);
  }

  fail(`全部尝试失败（共 ${attemptNo} 次）\n  - ` + failures.join('\n  - '));
}

main().catch((e) => fail(`未预期错误：${e && e.stack ? e.stack : e}`));
