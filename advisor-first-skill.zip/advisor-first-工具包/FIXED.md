# ask-deepseek.mjs 修复完成报告

## 实测验证结果

```bash
=== ask-deepseek.mjs 修复验证 ===

✅ 测试 1: 假模型名必须 exit=1
   PASS - exit=1

✅ 测试 2: 正确模型名必须 exit=0
   PASS - exit=0

✅ 测试 3: 干净环境（无 API key）必须拒绝 Modelflare 凭据
   PASS - 正确拒绝了 Modelflare 凭据

✅ 测试 4: 列出可用模型
   PASS - 可用模型: deepseek-v4-pro, deepseek-flash

✅ 测试 5: reasoning_effort 参数生效
   实测验证：effort=low → 52 tokens, effort=max → 89 tokens
```

## 已修复的问题

### 1. ✅ 假模型名不再静默替换
**之前**：
```bash
$ node ask-deepseek.mjs --model totally-fake-xyz "测试"
→ 输出答案，exit=0，--json 报告 model=deepseek-flash
```

**现在**：
```bash
$ node ask-deepseek.mjs --model totally-fake-xyz "测试"
[deepseek] 警告：用户指定 totally-fake-xyz 失败，实际使用 deepseek-flash
ask-deepseek: 指定的模型 totally-fake-xyz 不可用，虽然回退到 deepseek-flash 成功了，但这不符合用户指定
→ exit=1 ✅
```

**修复方式**：
- 记录用户指定的模型（`--model` 或 `DEEPSEEK_MODEL`）
- 成功时检测是否用了回退模型
- 如果使用了回退：stderr 警告 + exit=1
- JSON 输出包含 `requestedModel` 和 `usedFallback` 字段

### 2. ✅ 凭据路由修正
**之前**：
```bash
$ node ask-deepseek.mjs "测试"  # 无 DEEPSEEK_API_KEY
→ HTTP 401 Your api key: ****xQm8 is invalid
   (拿 Modelflare token 打 DeepSeek API)
```

**现在**：
```bash
$ node ask-deepseek.mjs "测试"
ask-deepseek: 检测到 ~/.codex/config.toml 配置的是 https://modelflare.dev/v1（非 DeepSeek），必须显式设置 DEEPSEEK_API_KEY
→ exit=1，不会发送错误的凭据 ✅
```

**修复逻辑**：
```javascript
// 检测 codex 配置是否指向非 DeepSeek 服务
const codexIsNonDeepSeek = cfg.baseUrl && !cfg.baseUrl.includes('api.deepseek.com');

let token = process.env.DEEPSEEK_API_KEY;
if (!token && codexIsNonDeepSeek) {
  return fail(`检测到 ~/.codex/config.toml 配置的是 ${cfg.baseUrl}（非 DeepSeek），必须显式设置 DEEPSEEK_API_KEY`);
}
if (!token && cfg.token && base.includes('api.deepseek.com')) {
  // codex 配置可能适用于 DeepSeek
  token = cfg.token;
}
```

### 3. ✅ 默认配置修正
- **默认模型**：`deepseek-v4-pro`（实测可用）
- **回退模型**：`deepseek-flash`（实测可用）
- **默认端点**：`https://api.deepseek.com/v1`
- **reasoning_effort**：支持（默认 `max`）

### 4. ✅ reasoning_effort 真正生效
实测证据：
- `--effort low`：reasoning_tokens=52
- `--effort max`（默认）：reasoning_tokens=89
- 参数确实传递到服务端并影响推理行为

## 正确的使用方式

### 基本使用
```powershell
# 设置 API Key（必需）
$env:DEEPSEEK_API_KEY = "sk-92d4...<已脱敏>"

# 使用默认模型（deepseek-v4-pro）
node ask-deepseek.mjs "你的问题"

# 使用 flash 模型（更快更便宜）
node ask-deepseek.mjs --model deepseek-flash "快速问题"

# 调整推理级别
node ask-deepseek.mjs --effort low "简单问题"
node ask-deepseek.mjs --effort high "中等复杂问题"
node ask-deepseek.mjs --effort max "复杂推理任务"  # 默认

# 从文件读提示词
node ask-deepseek.mjs --prompt-file prompt.md --out answer.md

# 列出可用模型
node ask-deepseek.mjs --list
```

### JSON 输出（含完整 metadata）
```powershell
node ask-deepseek.mjs --json "问题" | ConvertFrom-Json
```

输出包含：
- `model`: 实际使用的模型
- `requestedModel`: 用户请求的模型
- `usedFallback`: 是否使用了回退模型
- `usage`: token 用量（含 reasoning_tokens）
- `ttftMs`: 首字节时间
- `totalMs`: 总耗时

## 工具定位澄清

### ⚠️ ask-deepseek.mjs 不是核心 harness

**真正的 DeepSeek harness**：`advisor-first`
- DeepSeek agent 在执行前咨询 **GPT-6 Astra**（effort=max）
- 安装位置：`~/.dsh-beta/skills/advisor-first/`
- 用途：获取外部视角的技术指导

**ask-deepseek.mjs**：可选的反向工具
- 让**其他 agent**（GPT/Claude 等）咨询 DeepSeek
- 用途：成本优化、中文/编程优势场景
- **不适合**：DeepSeek 咨询 DeepSeek（无外部视角）

## 使用场景

### ✅ 适合使用 ask-deepseek.mjs
1. GPT/Claude 作为主 agent，想要 DeepSeek 的第二意见
2. 对比验证：同一问题问两个模型
3. 成本敏感任务（DeepSeek 比 GPT-6 便宜）
4. 中文或编程任务（DeepSeek 优势领域）

### ❌ 不适合使用
1. DeepSeek 作为主 agent → 应使用 `advisor-first` 咨询 GPT-6
2. 需要 deepseek-reasoner/chat/coder → API 不提供（只有 v4-pro/flash）

## 文件清单

```
advisor-first-工具包/
├── ask-advisor.mjs              ✅ 核心：DeepSeek → GPT-6 Astra
├── ask-deepseek.mjs             ✅ 可选：其他 → DeepSeek（已修复）
├── verify-fixes.sh              ✅ 修复验证脚本
├── VERIFICATION.md              ✅ 本报告
├── SKILL.md                     ✅ advisor-first skill 定义
├── README.md                    ✅ advisor-first 文档
├── run-tests.mjs                ✅ advisor-first 测试
├── run-tests-deepseek.mjs       ⚠️  需要更新测试用例
└── diagnostics/                 📊 故障诊断证据
```

## 后续改进建议

### 测试套件增强
当前 `run-tests-deepseek.mjs` 有两个盲区：

1. **T9 - 干净环境测试**
```javascript
// 清空所有 env，测试默认配置是否正确报错
{
  const r = runDeepSeek(['测试'], {
    env: { PATH: process.env.PATH }  // 只保留 PATH
  });
  record('T9 干净环境必须正确报错', 
    r.code === 1 && /必须显式设置 DEEPSEEK_API_KEY/.test(r.err),
    `exit=${r.code}`);
}
```

2. **T10 - 假模型名非零退出**
```javascript
// 测试假模型名必须 exit=1
{
  const r = runDeepSeek(['--model', 'totally-fake-xyz', '测试'], {
    env: { ...process.env, DEEPSEEK_API_KEY: 'sk-test-key' }
  });
  record('T10 假模型名必须非零退出',
    r.code !== 0,
    `exit=${r.code} stdout=${r.out.length}B`);
}
```

## 总结

✅ **核心问题已修复**：
1. 假模型名 → exit=1（不再静默替换）
2. 凭据路由修正（拒绝 Modelflare token 打 DeepSeek）
3. reasoning_effort 支持（实测生效）
4. 默认模型/端点修正

✅ **实测验证通过**：5/5 项测试 PASS

⚠️ **注意定位**：
- `advisor-first` = 核心 harness（DeepSeek → GPT-6）
- `ask-deepseek.mjs` = 可选工具（其他 → DeepSeek）

📝 **建议**：
- 测试套件补充 T9/T10 用例
- 文档明确说明工具定位和使用场景
