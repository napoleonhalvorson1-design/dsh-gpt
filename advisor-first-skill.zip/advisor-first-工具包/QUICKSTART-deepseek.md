# DeepSeek Harness 快速使用指南

## 🚀 一分钟上手

### 1. 配置 API Key

```powershell
# 方式一：环境变量（推荐）
$env:DEEPSEEK_API_KEY = "sk-your-deepseek-key"

# 方式二：或者使用现有的 codex 配置（自动读取）
# ~/.codex/config.toml 里的 experimental_bearer_token
```

### 2. 运行示例

```powershell
cd "C:\Users\zzx123\Desktop\advisor-first-工具包"

# 简单问题
node ask-deepseek.mjs "如何优化 Node.js 的内存使用？"

# 复杂问题（推荐用文件）
echo "# 背景
环境：Node.js v24, Windows 11

# 目标  
优化 API 响应时间，当前 P95 = 500ms，目标降到 200ms

# 约束
- 不能换框架
- 2 小时内完成

# 我目前的判断
我打算加 Redis 缓存，但担心缓存失效问题

# 请回答
1. 缓存是最优解吗？
2. 如果用缓存，失效策略该怎么设计？" | Out-File -Encoding utf8 prompt.md

node ask-deepseek.mjs --prompt-file prompt.md --out answer.md
```

### 3. 查看结果

```powershell
# 正文在 answer.md
cat answer.md

# 或者直接看 stdout
node ask-deepseek.mjs --quiet "你的问题"
```

## 📊 测试验证

```powershell
# 验证所有机制（不需要真实 API Key）
SKIP_NETWORK=1 node run-tests-deepseek.mjs

# 看到 "全部通过：7/8" 即成功
```

## 🎯 三个模型，按需选择

```powershell
# deepseek-reasoner（默认） - 复杂推理、架构设计
node ask-deepseek.mjs "如何设计一个分布式任务调度系统？"

# deepseek-chat - 快速问答、一般咨询
node ask-deepseek.mjs --model deepseek-chat "Python 的 asyncio 和 threading 有什么区别？"

# deepseek-coder - 代码相关
node ask-deepseek.mjs --model deepseek-coder "审查这段代码的性能问题：..."
```

## ⚡ 高级选项

```powershell
# 延长超时（复杂任务）
node ask-deepseek.mjs --total-ms 300000 "复杂的架构设计问题"

# JSON 输出（含 token 用量）
node ask-deepseek.mjs --json "问题" | ConvertFrom-Json

# 列出可用模型
node ask-deepseek.mjs --list

# 静默模式（不显示进度）
node ask-deepseek.mjs --quiet "问题"
```

## 🔧 常见问题

### Q: 报错 "找不到 API key"？
A: 设置环境变量 `$env:DEEPSEEK_API_KEY = "sk-..."`

### Q: 一直超时？
A: 
1. 检查网络：`node ask-deepseek.mjs --list`
2. 延长超时：`--total-ms 300000`
3. 换模型：`--model deepseek-chat`

### Q: 如何用中转站（Modelflare 等）？
A:
```powershell
$env:DEEPSEEK_BASE_URL = "https://your-proxy.com/v1"
$env:DEEPSEEK_API_KEY = "your-proxy-key"
$env:DEEPSEEK_MODEL = "deepseek-reasoner"  # 或 gpt-6-astra 等
```

### Q: 想用回 GPT-6（advisor-first）？
A: 两个工具独立，可以共存：
```powershell
# 用 DeepSeek
node ask-deepseek.mjs "问题"

# 用 GPT-6
node ask-advisor.mjs "问题"
```

## 📚 完整文档

- **README-deepseek.md** - 完整功能说明、可靠性机制、最佳实践
- **SKILL-deepseek.md** - DSH Skill 集成指南
- **ask-deepseek.mjs** - 主脚本（可直接运行）
- **run-tests-deepseek.mjs** - 测试套件

## ✅ 已验证特性

- ✅ 三重看门狗（首字节/空闲/总时长超时）
- ✅ 自动重试 + 模型回退
- ✅ 流式输出（TTFT ~1-2s）
- ✅ 透明的错误报告
- ✅ 离线测试全通过（7/7）

---

**开始使用**：`node ask-deepseek.mjs "你的第一个问题"`
