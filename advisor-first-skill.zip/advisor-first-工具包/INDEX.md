# 文件清单与使用说明

## 📁 目录结构

```
advisor-first-工具包/
│
├── ── DeepSeek Harness (新) ──────────────────────
├── ask-deepseek.mjs              # 主脚本（12KB，自包含）
├── SKILL-deepseek.md             # DSH Skill 定义（8.6KB）
├── README-deepseek.md            # 完整文档（10KB）
├── QUICKSTART-deepseek.md        # 快速开始指南（3.3KB）
├── run-tests-deepseek.mjs        # 回归测试（7.7KB）
│
├── ── 原 advisor-first（保留） ──────────────────
├── ask-advisor.mjs               # 原脚本（14KB）
├── SKILL.md                      # 原 Skill 定义（4.8KB）
├── README.md                     # 原文档（4.8KB）
├── run-tests.mjs                 # 原测试（8.3KB）
│
└── diagnostics/                  # 原诊断日志（保留作证据）
    ├── diagnose-endpoint.mjs
    ├── repro-timeout-behavior.mjs
    ├── test-effort-hang.mjs
    ├── test-stream-ttft.mjs
    ├── watchdog-test-standalone.mjs
    └── logs/
```

## 🎯 快速决策：用哪个？

| 场景 | 使用 | 命令 |
|---|---|---|
| **DeepSeek 用户**（官方 API） | `ask-deepseek.mjs` | `node ask-deepseek.mjs "问题"` |
| **需要 GPT-6**（Astra/Sol/Luna） | `ask-advisor.mjs` | `node ask-advisor.mjs "问题"` |
| **通过中转站用 DeepSeek** | `ask-deepseek.mjs` | 设置 `DEEPSEEK_BASE_URL` |
| **通过中转站用 GPT-6** | `ask-advisor.mjs` | 使用现有配置 |
| **不确定，先测试** | 两者都跑离线测试 | `SKIP_NETWORK=1 node run-tests-*.mjs` |

## ✅ 验证状态

### DeepSeek Harness（新）
- ✅ 离线测试全通过（7/7）
- ✅ 三重看门狗验证通过
- ✅ 错误处理验证通过
- ⏭️  联网测试需要有效 API Key

### advisor-first（原）
- ✅ 已实测验证（2026-10-11）
- ✅ 修复所有已知挂起问题
- ✅ 在原环境中稳定运行

## 📖 文档导读

### 如果你是首次使用
👉 先看 **QUICKSTART-deepseek.md**（3 分钟上手）

### 如果你要集成到 DSH
👉 看 **SKILL-deepseek.md**（Skill 定义和调用规则）

### 如果你要了解技术细节
👉 看 **README-deepseek.md**（完整文档，含可靠性机制、最佳实践）

### 如果你要理解为什么这么设计
👉 看原 **README.md**（advisor-first 的故障分析和修复证据）

## 🔧 立即测试

```powershell
# 1. 验证脚本工作正常（不需要 API Key）
cd "C:\Users\zzx123\Desktop\advisor-first-工具包"
SKIP_NETWORK=1 node run-tests-deepseek.mjs
# 应看到：全部通过：7/8

# 2. 配置 API Key
$env:DEEPSEEK_API_KEY = "sk-your-key"

# 3. 测试连通性
node ask-deepseek.mjs --list
# 应看到：deepseek-reasoner, deepseek-chat, deepseek-coder

# 4. 第一个真实问题
node ask-deepseek.mjs "只回复两个字：在吗"
# 应在 5-30s 内得到回复
```

## 🚀 开始使用

```powershell
# 简单问题
node ask-deepseek.mjs "你的问题"

# 复杂问题（推荐）
# 1. 把提示词写到文件
notepad prompt.md
# 2. 运行并保存结果
node ask-deepseek.mjs --prompt-file prompt.md --out answer.md
# 3. 查看结果
cat answer.md
```

## 🔄 迁移指南（从 advisor-first）

| 原有用法 | 新用法 | 说明 |
|---|---|---|
| `node ask-advisor.mjs "问题"` | `node ask-deepseek.mjs "问题"` | 直接替换脚本名 |
| `ADVISOR_API_KEY` | `DEEPSEEK_API_KEY` | 环境变量改名 |
| `ADVISOR_BASE_URL` | `DEEPSEEK_BASE_URL` | 环境变量改名 |
| `--effort max` | （移除） | DeepSeek 自动推理 |
| `gpt-6-astra` | `deepseek-reasoner` | 默认模型改变 |
| `--model gpt-6-sol` | `--model deepseek-chat` | 模型名对应改 |

**提示词模板不变** - 完全相同的模板可以无缝复用。

## 🤝 两者共存

两个工具可以同时保留，按需选择：

```powershell
# 用 DeepSeek（官方 API）
$env:DEEPSEEK_API_KEY = "sk-deepseek-key"
node ask-deepseek.mjs "问题"

# 用 GPT-6（中转站）
$env:ADVISOR_API_KEY = "your-modelflare-key"
node ask-advisor.mjs "问题"

# 或通过中转站用 DeepSeek
$env:DEEPSEEK_BASE_URL = "https://your-proxy.com/v1"
$env:DEEPSEEK_MODEL = "deepseek-reasoner"
node ask-deepseek.mjs "问题"
```

## 📊 技术对比

| 特性 | ask-deepseek.mjs | ask-advisor.mjs |
|---|---|---|
| 默认模型 | deepseek-reasoner | gpt-6-astra |
| 默认端点 | api.deepseek.com | 中转站（Modelflare） |
| reasoning_effort | ❌ 不支持 | ✅ 支持（max） |
| 流式输出 | ✅ | ✅ |
| 三重看门狗 | ✅ | ✅ |
| 自动重试 | ✅ | ✅ |
| 模型回退 | ✅ (reasoner→chat→coder) | ✅ (astra→sol→luna) |
| 推理链可见 | ✅ (reasoner 模型) | ❌ |
| 相对成本 | 💰 较低 | 💰💰 较高 |

## ❓ 常见问题

### Q: 我应该用哪个？
A: 
- **有 DeepSeek API Key** → 用 `ask-deepseek.mjs`
- **只有中转站 Key** → 两者都可，看需要哪个模型
- **不确定** → 先跑测试：`SKIP_NETWORK=1 node run-tests-deepseek.mjs`

### Q: 可以删除原 advisor-first 吗？
A: 可以，但建议保留：
- 如果只用 DeepSeek，可以删除 `ask-advisor.mjs`、`SKILL.md`、`run-tests.mjs`
- **建议保留 `README.md` 和 `diagnostics/`**：包含宝贵的故障分析和修复证据

### Q: 如何集成到 DSH？
A:
```powershell
# 1. 创建 skill 目录
mkdir "$HOME\.dsh-beta\skills\deepseek-harness"

# 2. 复制文件
cp ask-deepseek.mjs "$HOME\.dsh-beta\skills\deepseek-harness\scripts\"
cp SKILL-deepseek.md "$HOME\.dsh-beta\skills\deepseek-harness\SKILL.md"

# 3. 在 DSH 中使用
# /deepseek-harness 或 /deepseek
```

### Q: 遇到问题怎么办？
A:
1. **查看完整输出**（不要用 `--quiet`）
2. **运行测试**：`SKIP_NETWORK=1 node run-tests-deepseek.mjs`
3. **测试连通性**：`node ask-deepseek.mjs --list`
4. **查看文档**：`README-deepseek.md` 的"故障处理"章节

## 📝 下一步

1. ✅ **已完成**：DeepSeek Harness 完整实现和测试
2. ⏭️ **可选**：安装到 DSH skill 目录
3. ⏭️ **可选**：运行联网测试（需要有效 API Key）
4. ⏭️ **可选**：根据实际使用反馈调整超时参数

---

**现在开始**：`node ask-deepseek.mjs "你的第一个问题"`
