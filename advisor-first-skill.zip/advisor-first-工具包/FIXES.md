# ask-deepseek.mjs 修复记录（实测）

本文件只记录**本条修复里实际跑过的命令与输出**。没有跑过的结论不写。

---

## 一、修好之前的状态（复现命令 + 原始输出）

| # | 问题 | 复现 | 实际输出 |
|---|---|---|---|
| 1 | 默认模型不存在 | `node ask-deepseek.mjs --list` | 真实可用只有 `deepseek-flash` / `deepseek-v4-pro`，而默认是 `deepseek-reasoner` |
| 2 | 凭据路由错 | 干净环境 `node ask-deepseek.mjs "hi"` | `HTTP 401 ... Your api key: ****xQm8 is invalid`（xQm8 = Modelflare 令牌） |
| 3 | 静默替换模型 | `--model totally-fake-xyz "hi"` | 打印正文，**exit=0** |
| 4 | 凭据检查顺序错 | `node ask-deepseek.mjs`（空提示词） | 报「必须设置 DEEPSEEK_API_KEY」而不是「没有提示词」 |
| 5 | 中文被吃字 | `--out` 落盘后读回 | 正文含 `U+FFFD`（「计」→ `\uFFFD`） |

---

## 二、改了什么

### 1. 参数校验顺序：先参数，后凭据

原来凭据检查在最前，导致**参数类错误被环境类错误覆盖**。现在顺序是：
`解析参数 → 校验提示词/--prompt-file → 解析凭据 → 执行`。
`--list` 不需要提示词，单独跳过提示词校验。

### 2. 凭据解析：只允许与端点匹配的凭据

优先级：`DEEPSEEK_API_KEY` 环境变量 → `~/.dsh-beta/.credentials.yaml` 的 `refs.DEEPSEEK_API_KEY`
→ `~/.codex/config.toml`（**仅当它的 base_url 也指向 api.deepseek.com**）。

**绝不再把 A 家的令牌发去 B 家端点**——那只会换来 401、白等一轮重试，还把真因藏起来。

失败时的报错会列出三条可操作路径，不再只说"必须设环境变量"。

### 3. `readCodexProvider()` 只读**当前生效**的 provider 块

原实现抓文件里第一个 `base_url` / `experimental_bearer_token`。但该文件可以同时有
多个 provider 块（本机就有 `[model_providers.fox]` 和 `[model_providers.custom]`），
抓错一个就拿错凭据。现在按 `model_provider = "<name>"` 定位到对应块再取。

### 4. 凭据来源透明化

每次调用在 stderr 打印：`端點=<base> 凭据来源=<哪里来的>`。
用户必须能知道自己正在用谁的身份。

### 5. ★ 中文被吃字（`U+FFFD`）—— 这是最隐蔽的一个

**根因**：`Buffer.from(chunk).toString('utf8')` 对每个 chunk **独立解码**。
一个中文字符占 3 字节，被 TCP 分片切开时，前半截单独解码失败 → `U+FFFD`，
而且这个损坏会**一路写进 `--out` 文件**，不是显示问题。

**修复**：改用 `node:string_decoder` 的 `StringDecoder`，它把不完整的多字节序列
留到下一个 chunk 再拼。

**证据**（`node test-utf8-boundary.mjs`，直接对解码函数做确定性断言，不依赖网络分片运气）：

```
「计」= E8 AE A1，位于第 45 字节

切法 [1 字节] + [2 字节]：
  旧写法 = "例如���算阶乘"      ← 损坏，bug 复现
  新写法 = "例如计算阶乘"       ← 完好

切法 [2 字节] + [1 字节]：
  旧写法 = "例如��算阶乘"
  新写法 = "例如计算阶乘"

极端：逐字节切分（78 个 chunk）：
  旧写法 = "������������������"
  新写法 = "例如计算阶乘"

对照：不切分时两种写法都完好 → 证明差异确实来自切点
```

⚠️ 这个 bug **同时存在于 `ask-advisor.mjs`**（两处副本），已一并修复并同步到 skill 目录。

---

## 三、修复后的验证（全部实跑）

| 检查 | 命令 | 结果 |
|---|---|---|
| 干净环境默认配置 | `node ask-deepseek.mjs "只回复两个字：在吗"` | **exit=0**，`TTFT 227ms`，凭据来源显示 `.credentials.yaml` |
| 空提示词 | `node ask-deepseek.mjs` | exit=1，报「没有提示词」（不再是凭据错误） |
| 文件不存在 | `--prompt-file C:\nope\x.md` | exit=1，报「提示词文件不存在：…」 |
| `--list` | `--list` | exit=0，列出 `deepseek-flash` / `deepseek-v4-pro` |
| `--help` | `--help` | exit=0 |
| 假模型名 | `--model totally-fake-xyz "hi"` | **exit=1**（stdout 仍有正文，但退出码是明确信号） |
| 中文完整性 | `--out` 落盘后读回 | **无 `U+FFFD`** |
| deepseek 套件 | `node run-tests-deepseek.mjs` | **8/8，exit=0** |
| advisor 套件 | `node run-tests.mjs` | **8/8，exit=0** |
| UTF-8 边界套件 | `node test-utf8-boundary.mjs` | **5/5，exit=0** |
| 退出码稳定性 | `node stress-exit.mjs 25` | **25/25 exit=0**，无非预期崩溃 |

### 关于 `0xC0000409`

排查过程中见过一次 `exit=-1073740791`（`0xC0000409`）。**已确认不是脚本问题**：

- `stress-exit.mjs` 用 `spawnSync` 直接取退出码，**25/25 全为 0**；
- 用 PowerShell 复现同一命令 3 次全部 `exit=0`；
- 唯一能复现的是 `node ... 2>&1 | Select-Object -First 1` 这种**管道被提前关闭**的写法——
  此时 PowerShell 报的是它自己的管道退出码。

**结论**：该值是 PowerShell 管道造成的测量假象。若要用 PowerShell 验证退出码，
不要用 `| Select-Object -First N` 截断管道。

---

## 四、这个工具与 `advisor-first` 的关系

| | `ask-advisor.mjs` | `ask-deepseek.mjs` |
|---|---|---|
| 用途 | DSH(DeepSeek) 咨询**外部**强模型 | 其他 agent 咨询 DeepSeek |
| 默认顾问 | `gpt-6-astra`（经 Modelflare） | `deepseek-v4-pro`（官方 API） |
| 装在哪 | `~/.dsh-beta/skills/advisor-first/` | 仅桌面分发副本 |
| skill 名 | `/advisor-first` | 无（未安装） |

**`advisor-first` 才是那个 harness**：它的意义是「DeepSeek 在执行前咨询外部模型」。
用 DeepSeek 咨询 DeepSeek 没有外部视角，所以 `ask-deepseek.mjs` 定位是**可选工具**，
不需要装进 skill 目录。
