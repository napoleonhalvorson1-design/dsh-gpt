# advisor-first 工具包

把「开工前先问一个外部强模型」做成可复用工具，**并修掉了它原来的可靠性问题**。

- 打包日期：2026-10-11
- 运行环境：Windows 11 + PowerShell 7.6.6 + Node v24.15.0
- 默认顾问：`gpt-6-astra`（effort=max），经 Modelflare 中转

---

## 一、这是什么问题、怎么修的

### 原来的故障

调用顾问**经常挂 7 分钟以上，看起来像死了**，最后被外部进程强杀（`exit=-1`、stderr 0 字节）。

### 根因（全部有实测证据，不是推测）

| # | 根因 | 证据 |
|---|---|---|
| 1 | **非流式模式要等整段生成完才返回第一个字节** | 同一问题总时长 1.1s–34s 波动；流式 TTFT 只有 1.0–1.6s |
| 2 | **`AbortSignal.timeout()` 在「建连/等响应头」阶段不生效** | 显式给 `--timeout 95000`，实际跑了 **176.67s** 才被外层杀掉 |
| 3 | **中转站持续发 SSE 保活心跳，会击穿「按字节重置」的空闲超时** | 实测：首字节 11.9s 到达后靠心跳硬撑满 240s 总超时；另一次实测抓拍到「正文停止增长 45303ms，但 1600ms 前仍有字节到达 = 只有保活心跳」 |
| 4 | 失败时 stderr 为空，调用方**看不到任何信息** | 旧版失败时 stdout/stderr 均 0 字节，纯黑盒 |

### 对照数据（同一端点、同一凭据）

| 配置 | 结果 |
|---|---|
| 无 `reasoning_effort` 参数，非流式 | 24/24 成功，耗时 1.1–1.6s |
| `effort:"max"`，**流式** | TTFT **1.6s**，成功 |
| `effort:"max"`，非流式（旧版行为） | 偶发 130s / 177s 后被杀 |
| `--list`（失败后立刻探测） | exit=0 / 0.66s ✅ |

**结论：端点和凭据都没问题，问题全在客户端实现。**

---

## 二、修了什么

| 改动 | 解决 |
|---|---|
| **默认流式** `stream: true` | TTFT 从 30s 级降到 ~1.6s |
| **自建 `AbortController` + 三重看门狗**，不再依赖 `AbortSignal.timeout()` | 建连阶段也能中断（实测 5017ms 准时中断） |
| 看门狗判据 = **正文增长**，不是「收到字节」 | 心跳击穿问题被根除，且能区分「纯心跳」与「真卡死」 |
| **每 1 秒轮询**检查（`setInterval`） | 中断及时，不会等到下一个 chunk 才判断 |
| **有界重试 + 退避**（默认每模型 3 次，1.5s/3s） | 瞬时故障自愈 |
| **模型回退链** astra → sol → luna | 单模型不可用时仍能出结果 |
| **stderr 活性输出** | 不再是黑盒，能看到「尝试 N / 首字节 Xms / 已接收 N 字」 |
| **`--out <file>`** | 正文直接落盘 |
| 进程级兜底 `main().catch()` | 未捕获异常一律 exit=1，绝不留在挂起态 |

### 三档看门狗默认值

| 档次 | 默认 | 依据 |
|---|---|---|
| 首字节超时 | 30s | 实测 ~1.6s，给 20 倍余量 |
| 正文停止增长 | 60s | 生成期内容连续到达 |
| 单次尝试总时长 | 120s | 成功请求实测 5–40s |

意图：**最坏情况下 5 分钟内必然给出结论**（含全部重试与模型回退），而不是无限挂起。

---

## 三、怎么用

```powershell
# 推荐：提示词写文件（避免 PowerShell 引号地狱）
node ask-advisor.mjs --prompt-file 问题.md --out 回答.md

# 短问题
node ask-advisor.mjs "你的问题"

# 换模型 / 降 effort / 调超时
node ask-advisor.mjs --model gpt-6-sol --effort high "问题"
node ask-advisor.mjs --ttft-ms 60000 --total-ms 300000 "很长的任务"

# 工具
node ask-advisor.mjs --list      # 列出中转站可用模型
node ask-advisor.mjs --json "问题"
node ask-advisor.mjs --help
```

**凭据不用配**：自动从 `~/.codex/config.toml` 读 `base_url` + `experimental_bearer_token`。
覆盖用环境变量 `ADVISOR_API_KEY` / `ADVISOR_BASE_URL` / `ADVISOR_MODEL` / `ADVISOR_EFFORT`。

---

## 四、跑测试

```powershell
node run-tests.mjs                  # 全部（含联网冒烟）
$env:SKIP_NETWORK=1; node run-tests.mjs   # 只跑离线部分
```

覆盖 8 项：三档看门狗能否中断病态连接（本地假服务器精确模拟）、对照不误杀、
参数校验类失败的退出码、失败时 stderr 是否含 HTTP 状态、联网冒烟是否真拿到非空正文。

**退出码 0 = 全通过。** 改动 `ask-advisor.mjs` 的看门狗逻辑后，
记得同步 `run-tests.mjs` 里复刻的那份，否则测试会失真。

---

## 五、SKILL.md 与安装位置

这个工具在 DSH 里的正式身份是一个 **skill**，安装于：

```
C:\Users\zzx123\.dsh-beta\skills\advisor-first\
├── SKILL.md
└── scripts\ask-advisor.mjs
```

可以用 `/advisor-first` 斜杠手势直接调用（已实测生效）。

**本包 = 该工具的可分发副本 + 测试 + 证据**，改完请同步回 skill 目录。
