# ask-deepseek.mjs - DeepSeek API 调用工具

## ⚠️ 重要说明

**这不是 DeepSeek Harness 的核心组件。**

- **advisor-first** = DeepSeek agent 在执行前咨询 GPT-6 Astra 获取指导（这才是真正的 harness）
- **ask-deepseek.mjs** = 可选的反向工具，让其他 agent 可以咨询 DeepSeek

## 🎯 定位

如果你已经有 GPT-6/Claude 作为主 agent，这个工具让它们可以：
- 咨询 DeepSeek 获取第二意见（成本更低）
- 在 DeepSeek 擅长的领域（编程、中文）获取建议

但如果你的主 agent **就是** DeepSeek，那么：
- ✅ 使用 **advisor-first** 咨询 GPT-6 Astra（外部视角）
- ❌ 不要用 ask-deepseek.mjs（DeepSeek 咨询自己没意义）

## ✅ 已修复的问题

基于实测反馈，已修复：

1. ✅ **默认模型改为 deepseek-v4-pro**（实测可用）
2. ✅ **回退链改为 deepseek-flash**（实测可用）
3. ✅ **默认 base_url = api.deepseek.com/v1**（不再错误读取 Modelflare 配置）
4. ✅ **支持 reasoning_effort**（实测两模型都接受，默认 max）
5. ✅ **假模型名会正确报错并回退**（不再静默替换）

## 🧪 验证结果

```bash
# ✅ 列出实测可用模型
$ node ask-deepseek.mjs --list
deepseek-flash
deepseek-v4-pro

# ✅ deepseek-v4-pro 正常工作
$ node ask-deepseek.mjs --model deepseek-v4-pro "只回复两个字：在吗"
TTFT: 195ms, Total: 2317ms
输出: 在吗

# ✅ deepseek-flash 正常工作  
$ node ask-deepseek.mjs --model deepseek-flash "只回复两个字：收到"
TTFT: 476ms, Total: 4815ms
输出: 收到

# ✅ 假模型名正确报错并回退
$ node ask-deepseek.mjs --model totally-fake-xyz "测试"
[deepseek] 失败：HTTP 400 invalid model name
[deepseek] 该类错误不可重试，跳到下一个模型
[deepseek] 模型 totally-fake-xyz 未成功，回退到 deepseek-flash
[deepseek] 成功：model=deepseek-flash
```

## 📋 正确的配置

```powershell
# 必需
$env:DEEPSEEK_API_KEY = "sk-92d4...<已脱敏>"

# 可选（已有正确默认值）
$env:DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"  # 默认值
$env:DEEPSEEK_MODEL = "deepseek-v4-pro"                  # 默认值
$env:DEEPSEEK_EFFORT = "max"                             # 默认值
```

## 🚀 使用场景

### ✅ 合适的场景

1. **GPT/Claude 主 agent** 想咨询 DeepSeek（成本优势、编程/中文优势）
2. **对比验证**：同一问题问 GPT-6 和 DeepSeek，看建议差异
3. **成本敏感任务**：DeepSeek 比 GPT-6 便宜很多

### ❌ 不合适的场景

1. **DeepSeek 主 agent** 咨询 DeepSeek 自己 → 用 advisor-first 咨询 GPT-6
2. **需要 DeepSeek Reasoner** → 实测 API 不提供（只有 flash/v4-pro）
3. **需要 deepseek-chat/coder** → 实测 API 不提供

## 📊 与 advisor-first 的对比

| 项目 | advisor-first | ask-deepseek.mjs |
|---|---|---|
| **用途** | DeepSeek 咨询 GPT-6 | 其他 agent 咨询 DeepSeek |
| **主 agent** | DeepSeek/任意 | GPT/Claude/任意（除 DeepSeek） |
| **顾问** | GPT-6 Astra (effort=max) | DeepSeek (v4-pro/flash) |
| **核心性** | ✅ 核心 harness | ⚠️ 可选工具 |
| **可用模型** | gpt-6-astra/sol/luna/1-sol | deepseek-flash/v4-pro |
| **reasoning_effort** | ✅ 支持 | ✅ 支持（实测验证） |
| **实测 TTFT** | ~1.6s | 195-476ms |
| **成本** | 较高 | 较低 |

## 🔧 命令参考

```bash
# 基本使用
node ask-deepseek.mjs "你的问题"

# 指定模型
node ask-deepseek.mjs --model deepseek-flash "快速问题"

# 调整推理级别
node ask-deepseek.mjs --effort high "中等复杂度问题"

# 从文件读提示词
node ask-deepseek.mjs --prompt-file prompt.md --out answer.md

# 列出可用模型
node ask-deepseek.mjs --list

# JSON 输出（含 token 用量）
node ask-deepseek.mjs --json "问题"
```

## 📝 提示词模板

与 advisor-first 完全相同的模板：

```markdown
# 背景（本机已核实的事实）
- 环境：<OS / shell / 版本>
- 已知事实：<带路径或数字>

# 目标
<一句话说清要达成什么>

# 约束（硬性）
- <不能改什么、必须用什么>

# 我目前的判断（要求你反驳）
- 我打算：<你的方案>
- 我担心：<你最不确定的点>

# 请回答
1. <具体问题>

要求：直接给结论，不确定处标注"不确定"，禁止编造路径/命令/API。
```

## ⚠️ 已知限制

1. **模型可用性有限**：只有 flash/v4-pro，没有 reasoner/chat/coder
2. **中国境内访问**：api.deepseek.com 需要特殊网络环境
3. **与 Modelflare 配置冲突**：如果 ~/.codex/config.toml 配的是 Modelflare，需显式设置 DEEPSEEK_BASE_URL

## 📦 文件清单

```
advisor-first-工具包/
│
├── ── 核心（DeepSeek → GPT-6）──────
├── ask-advisor.mjs           ✅ advisor-first 核心脚本
├── SKILL.md                  ✅ advisor-first skill 定义
├── README.md                 ✅ advisor-first 文档
│
├── ── 可选（其他 → DeepSeek）──────
├── ask-deepseek.mjs          ⚠️ 可选反向工具
├── README-deepseek.md        ⚠️ 本文档
│
└── ── 测试与诊断 ──────────────
    ├── run-tests.mjs         ✅ advisor-first 测试
    ├── run-tests-deepseek.mjs ⚠️ ask-deepseek 测试
    └── diagnostics/          📊 故障诊断证据
```

## 🎯 总结

- **主要用途**：advisor-first（让 DeepSeek 咨询 GPT-6 Astra）
- **可选补充**：ask-deepseek.mjs（让其他 agent 咨询 DeepSeek）
- **不要混淆**：DeepSeek harness ≠ 咨询 DeepSeek 的工具

ask-deepseek.mjs 现已修复所有实测问题，可以正常工作。但它是**可选工具**，不是 DSH 的核心 harness。
