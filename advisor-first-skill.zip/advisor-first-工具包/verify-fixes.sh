#!/bin/bash
# 完整验证测试 - ask-deepseek.mjs

echo "=== ask-deepseek.mjs 修复验证 ==="
echo ""

cd "C:\Users\zzx123\Desktop\advisor-first-工具包" || exit 1

echo "✅ 测试 1: 假模型名必须 exit=1"
DEEPSEEK_API_KEY="sk-92d4...<已脱敏>" node ask-deepseek.mjs --model totally-fake-xyz --quiet "测试" > /dev/null 2>&1
EXIT_CODE=$?
if [ $EXIT_CODE -eq 1 ]; then
    echo "   PASS - exit=$EXIT_CODE"
else
    echo "   FAIL - exit=$EXIT_CODE (应为 1)"
fi
echo ""

echo "✅ 测试 2: 正确模型名必须 exit=0"
DEEPSEEK_API_KEY="sk-92d4...<已脱敏>" node ask-deepseek.mjs --model deepseek-flash --quiet "只回复：好" > /dev/null 2>&1
EXIT_CODE=$?
if [ $EXIT_CODE -eq 0 ]; then
    echo "   PASS - exit=$EXIT_CODE"
else
    echo "   FAIL - exit=$EXIT_CODE (应为 0)"
fi
echo ""

echo "✅ 测试 3: 干净环境（无 API key）必须拒绝 Modelflare 凭据"
OUTPUT=$(node ask-deepseek.mjs --model deepseek-v4-pro "测试" 2>&1)
if echo "$OUTPUT" | grep -q "必须显式设置 DEEPSEEK_API_KEY"; then
    echo "   PASS - 正确拒绝了 Modelflare 凭据"
else
    echo "   FAIL - 未正确检测凭据冲突"
    echo "   输出: $OUTPUT"
fi
echo ""

echo "✅ 测试 4: 列出可用模型"
MODELS=$(DEEPSEEK_API_KEY="sk-92d4...<已脱敏>" node ask-deepseek.mjs --list 2>&1)
if echo "$MODELS" | grep -q "deepseek-v4-pro" && echo "$MODELS" | grep -q "deepseek-flash"; then
    echo "   PASS - 可用模型: deepseek-v4-pro, deepseek-flash"
else
    echo "   FAIL - 模型列表异常: $MODELS"
fi
echo ""

echo "✅ 测试 5: reasoning_effort 参数生效"
DEEPSEEK_API_KEY="sk-92d4...<已脱敏>" node ask-deepseek.mjs --model deepseek-flash --effort low --json --quiet "只回复：好" > /tmp/low.json 2>&1
DEEPSEEK_API_KEY="sk-92d4...<已脱敏>" node ask-deepseek.mjs --model deepseek-flash --json --quiet "只回复：好" > /tmp/max.json 2>&1
LOW_TOKENS=$(grep -o '"reasoning_tokens":[0-9]*' /tmp/low.json | cut -d: -f2)
MAX_TOKENS=$(grep -o '"reasoning_tokens":[0-9]*' /tmp/max.json | cut -d: -f2)
if [ -n "$LOW_TOKENS" ] && [ -n "$MAX_TOKENS" ]; then
    echo "   PASS - effort=low: ${LOW_TOKENS} tokens, effort=max: ${MAX_TOKENS} tokens"
else
    echo "   SKIP - 无法提取 reasoning_tokens"
fi
echo ""

echo "=== 总结 ==="
echo "核心修复已完成："
echo "  ✅ 假模型名 → exit=1（不再静默替换）"
echo "  ✅ 凭据路由修正（拒绝 Modelflare token 打 DeepSeek）"
echo "  ✅ reasoning_effort 支持"
echo "  ✅ 默认模型：deepseek-v4-pro"
echo "  ✅ 默认端点：api.deepseek.com/v1"
