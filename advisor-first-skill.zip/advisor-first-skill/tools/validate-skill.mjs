// validate-skill.mjs — 用与 DSH 加载器同源的判据复核 SKILL.md 是否仍会被接受，
// 并 diff 出「本次编辑到底动了哪些行」（防止顺手改坏别的地方）。
//
// 用法：node validate-skill.mjs <技能目录> [备份目录]
// 退出码：0 = 前端格式合法；1 = 不合法

import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { createRequire } from 'node:module';

const [, , skillDir, backupDir] = process.argv;
if (!skillDir) { console.error('用法: node validate-skill.mjs <技能目录> [备份目录]'); process.exit(1); }

const skillPath = join(skillDir, 'SKILL.md');
if (!existsSync(skillPath)) { console.error(`FAIL 找不到 ${skillPath}`); process.exit(1); }

// ── 1) 取 YAML 解析器：优先用 DSH 自带的那个，全失败则留给 json 兜底 ──
const require = createRequire(import.meta.url);
let parseYaml = null;
const candidates = [
  'C:\\Program Files\\DSH Desktop Beta\\resources\\app\\node_modules\\yaml',
  'yaml',
];
for (const c of candidates) {
  try { parseYaml = require(c).parse; break } catch { /* 试下一个 */ }
}

// ── 2) 复刻 dsh-skill-filesystem 的 parseFrontmatter 语义（lib/index.js:783 起）──
const raw = readFileSync(skillPath, 'utf8');
const m = raw.match(/^---\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)/);
if (!m) { console.error('FAIL 没有合法的 YAML frontmatter 块'); process.exit(1); }
const yamlText = m[1];
const body = raw.slice(m[0].length);

let data;
if (parseYaml) {
  try { data = parseYaml(yamlText); }
  catch (e) { console.error(`FAIL frontmatter YAML 解析失败：${e.message}`); process.exit(1); }
} else {
  console.log('WARN 没找到 yaml 解析器，退化为逐字段正则检查');
  data = {};
  for (const key of ['name', 'description']) {
    const km = yamlText.match(new RegExp(`^${key}:\\s*(.+)$`, 'm'));
    if (km) data[key] = km[1].trim().replace(/^['"]|['"]$/g, '');
  }
  const wm = yamlText.match(/^whenToUse:\s*(.+)$/m);
  if (wm) data.whenToUse = wm[1].trim();
}

const stringField = (o, k) => (typeof o?.[k] === 'string' ? o[k] : undefined);
const name = stringField(data, 'name');
const description = stringField(data, 'description');
const whenToUse = stringField(data, 'whenToUse');
const whenNotToUse = stringField(data, 'whenNotToUse');
const isSkillName = (v) => /^[a-z0-9][a-z0-9-]*$/.test(v) && v.length <= 64;

const problems = [];
if (name === undefined) problems.push('frontmatter requires name（字符串）');
if (description === undefined) problems.push('frontmatter requires description（字符串）');
if (name !== undefined && !isSkillName(name)) problems.push(`invalid skill name "${name}"`);
if (data.whenToUse !== undefined && whenToUse === undefined) problems.push('whenToUse 存在但不是字符串');
if (data.whenNotToUse !== undefined && whenNotToUse === undefined) problems.push('whenNotToUse 存在但不是字符串');

console.log(`name        : ${name}`);
console.log(`description : ${description ? description.length + ' 字符' : '(缺)'}`);
console.log(`whenToUse   : ${whenToUse ? whenToUse.length + ' 字符' : '(缺，可选)'}`);
console.log(`whenNotToUse: ${whenNotToUse ? whenNotToUse.length + ' 字符（加载器不读，仅供人读）' : '(缺)'}`);
console.log(`metadata    : ${JSON.stringify(data.metadata ?? {})}`);
console.log(`body        : ${body.length} 字符`);
console.log(`YAML 解析器 : ${parseYaml ? 'DSH 自带 yaml 包（与加载器同源）' : '正则兜底'}`);

// ── 3) 与备份 diff：只报告差异行数与内容，确认改动范围受控 ──
if (backupDir) {
  const bakPath = join(backupDir, 'SKILL.md');
  if (existsSync(bakPath)) {
    const before = readFileSync(bakPath, 'utf8').split(/\r?\n/);
    const after = raw.split(/\r?\n/);
    const setB = new Map();
    before.forEach((l, i) => { if (!setB.has(l)) setB.set(l, i + 1); });
    const setA = new Map();
    after.forEach((l, i) => { if (!setA.has(l)) setA.set(l, i + 1); });
    const added = after.filter((l) => !setB.has(l));
    const removed = before.filter((l) => !setA.has(l));
    console.log(`\n--- diff vs 备份（行数 ${before.length} → ${after.length}）---`);
    console.log(`新增 ${added.length} 行 / 删除 ${removed.length} 行`);
    for (const l of removed) console.log(`  - ${l.slice(0, 100)}`);
    for (const l of added) console.log(`  + ${l.slice(0, 100)}`);
  } else {
    console.log(`\nWARN 备份里没有 SKILL.md：${bakPath}`);
  }
}

if (problems.length > 0) {
  console.error('\nFAIL ' + problems.join('；'));
  process.exit(1);
}
console.log('\nPASS 加载器会接受这个技能文件');
