#Requires -Version 7
<#
.SYNOPSIS
  安装 / 更新 advisor-first 技能到 DSH 技能目录。

.DESCRIPTION
  固定「备份 → 复制 → SHA256 校验」三步，避免手工复制常见的两个错误：
    · 漏掉 scripts\ 子目录（技能能加载，但调用时才报脚本不存在）
    · 覆盖旧版本却没有回退点

  目标已存在时会整体备份为 <目标>-bak-<时间戳>，不删除旧备份。

  脚本故意不写中文提示，也不依赖控制台编码：
  AGENTS.md 记录过「用 powershell.exe -File 调的老脚本仍是 5.1，GBK 坑照旧」，
  虽然本脚本用 pwsh 7 跑是安全的，但保持纯 ASCII 能让它在 5.1 下也不会乱码。

.PARAMETER TargetRoot
  技能根目录。默认 ~/.dsh-beta/skills。技能会装到 <TargetRoot>\advisor-first。

.PARAMETER SkillName
  技能目录名，默认 advisor-first。

.EXAMPLE
  pwsh -File .\install.ps1
.EXAMPLE
  pwsh -File .\install.ps1 -TargetRoot "$env:TEMP\skilltest"
#>
[CmdletBinding()]
param(
  [string]$TargetRoot = (Join-Path $HOME '.dsh-beta\skills'),
  [string]$SkillName  = 'advisor-first'
)

$ErrorActionPreference = 'Stop'

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$srcSkill = Join-Path $here 'advisor-first'
if (-not (Test-Path $srcSkill)) { throw "package incomplete: missing $srcSkill" }

$dest = Join-Path $TargetRoot $SkillName
Write-Host "source : $srcSkill"
Write-Host "target : $dest"

# ---- 1) 备份现有安装 ----
if (Test-Path $dest) {
  $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
  $bak = "$dest-bak-$stamp"
  Copy-Item $dest $bak -Recurse -Force
  Write-Host "backup : $bak"
} else {
  Write-Host 'backup : (none, fresh install)'
}

# ---- 2) 复制 ----
New-Item -ItemType Directory -Path $dest -Force | Out-Null
# 显式建 scripts 子目录：Copy-Item -Recurse 在目标已存在时行为不一致，别赌
New-Item -ItemType Directory -Path (Join-Path $dest 'scripts') -Force | Out-Null
Copy-Item (Join-Path $srcSkill 'SKILL.md') $dest -Force
Copy-Item (Join-Path $srcSkill 'scripts\ask-advisor.mjs') (Join-Path $dest 'scripts') -Force

# ---- 3) 写后校验：逐个 SHA256 比对 ----
$pairs = @(
  @{ Rel = 'SKILL.md';                   Src = (Join-Path $srcSkill 'SKILL.md') },
  @{ Rel = 'scripts\ask-advisor.mjs';    Src = (Join-Path $srcSkill 'scripts\ask-advisor.mjs') }
)

$bad = @()
foreach ($p in $pairs) {
  $dstFile = Join-Path $dest $p.Rel
  if (-not (Test-Path $dstFile)) { $bad += "$($p.Rel) (missing)"; continue }
  $h1 = (Get-FileHash $p.Src -Algorithm SHA256).Hash
  $h2 = (Get-FileHash $dstFile -Algorithm SHA256).Hash
  $ok = ($h1 -eq $h2)
  Write-Host ("  {0,-26} {1}  {2}" -f $p.Rel, $(if ($ok) { 'OK  ' } else { 'FAIL' }), $h2.Substring(0,16))
  if (-not $ok) { $bad += $p.Rel }
}

if ($bad.Count -gt 0) {
  Write-Error "verification failed for: $($bad -join ', ')"
  exit 1
}

Write-Host ''
Write-Host 'installed and verified.'
Write-Host "Use it in DSH with:  /$SkillName"
Write-Host 'DSH watches the skills directory (depth 1), so no restart is needed.'
