// stress-exit.mjs — 反复跑 ask-deepseek.mjs，统计退出码分布
//
// 为什么需要：实测出现过 0xC0000409 (STATUS_STACK_BUFFER_OVERRUN, 无符号 3221226505)。
// 这是 Node 在 stdout 仍有未 flush 的写操作时強退的表现，**间歇性**——
// 单跑一次通过不能证明它没坏。必须跑 N 次看分布。
//
// 用法：node stress-exit.mjs [次数]

import { spawnSync } from 'node:child_process';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const TARGET = join(HERE, 'ask-deepseek.mjs');
const N = Number(process.argv[2] || 20);

const codes = new Map();
const details = [];

for (let i = 1; i <= N; i++) {
  // stdout 走管道（模拟被 agent 捕获），正文短、不设 quiet 以触发 stderr 进度输出
  const r = spawnSync(process.execPath, [TARGET, '--quiet', '只回复两个字：在吗'], {
    encoding: 'utf8',
    timeout: 180000,
  });
  const code = r.status;
  codes.set(code, (codes.get(code) || 0) + 1);
  const flag = code === 0 ? 'ok  ' : 'BAD ';
  const outLen = (r.stdout || '').trim().length;
  process.stdout.write(`  #${String(i).padStart(2)} ${flag} exit=${String(code).padStart(12)}  stdout=${outLen}字\n`);
  if (code !== 0) details.push({ i, code, err: (r.stderr || '').slice(-300) });
}

process.stdout.write('\n=== 退出码分布 ===\n');
for (const [code, n] of [...codes.entries()].sort((a, b) => b[1] - a[1])) {
  const name = code === 0 ? '成功'
    : code === 1 ? '正常失败'
    : code === -1073740791 ? '0xC0000409 崩溃 ← 就是它'
    : code === null ? '被 timeout 杀掉'
    : '未知';
  process.stdout.write(`  exit=${String(code).padStart(12)}  ×${n}   ${name}\n`);
}

const bad = [...codes.keys()].filter((c) => c !== 0 && c !== 1);
if (bad.length === 0) {
  process.stdout.write(`\nPASS  ${N}/${N} 全部为 0 或 1，无非预期崩溃\n`);
  process.exitCode = 0;
} else {
  process.stdout.write(`\nFAIL  出现非预期退出码：${bad.join(', ')}\n`);
  for (const d of details.slice(0, 3)) process.stdout.write(`  #${d.i} exit=${d.code}\n    stderr 末尾: ${d.err.replace(/\s+/g, ' ')}\n`);
  process.exitCode = 1;
}
