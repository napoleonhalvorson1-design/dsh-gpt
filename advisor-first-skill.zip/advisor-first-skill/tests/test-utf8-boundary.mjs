// test-utf8-boundary.mjs — 证明「chunk 边界切断多字节字符」这个 bug 及其修复
//
// 背景：实测 ask-deepseek.mjs --out 落盘的中文里出现 U+FFFD（"计"字变成 \uFFFD）。
// 根因是 `Buffer.from(chunk).toString('utf8')` 对每个 chunk 独立解码：
// 「计」= E8 AE A1 三字节，若分片正好切在中间，前半截单独解码就失败 → U+FFFD，
// 且损坏会一路写进产物文件。
//
// 为什么直接测解码函数、而不是走网络：
// 第一版用本地服务器 + fetch 试图制造跨 chunk 边界，结果 undici 把同批写入的
// 字节合并成一个 chunk，切点根本没落地（实测 1 个 chunk，测试假通过）。
// 网络分片时机不可控，因此这里把「字节切法」当成输入参数，直接断言解码结果——
// 确定、可复现、不依赖运气。

import { StringDecoder } from 'node:string_decoder';

const SENTENCE = '例如计算阶乘';   // 「计」在第 3 个字符

/** 把整段 SSE 文本按给定切点切成 Buffer 数组，模拟网络分片 */
function makeChunks(text, splitPoints) {
  const full = Buffer.from(text, 'utf8');
  const chunks = [];
  let prev = 0;
  for (const p of splitPoints) {
    if (p > prev && p <= full.length) { chunks.push(full.subarray(prev, p)); prev = p; }
  }
  if (prev < full.length) chunks.push(full.subarray(prev));
  return chunks;
}

/** 旧写法：每个 chunk 独立 toString */
function parseOld(chunks) {
  let buf = '';
  for (const c of chunks) buf += Buffer.from(c).toString('utf8');
  return extract(buf);
}

/** 新写法：StringDecoder 跨 chunk 拼接 */
function parseNew(chunks) {
  const d = new StringDecoder('utf8');
  let buf = '';
  for (const c of chunks) buf += d.write(c);
  return extract(buf);
}

function extract(buf) {
  let out = '';
  for (const line of buf.split('\n')) {
    const t = line.trim();
    if (!t.startsWith('data:')) continue;
    const d = t.slice(5).trim();
    if (d === '[DONE]') continue;
    try {
      const j = JSON.parse(d);
      const c = j.choices?.[0]?.delta?.content;
      if (typeof c === 'string') out += c;
    } catch {}
  }
  return out;
}

const SSE = `data: ${JSON.stringify({ choices: [{ delta: { content: SENTENCE } }] })}\n\ndata: [DONE]\n\n`;

const results = [];
function check(name, pass, detail) {
  results.push({ name, pass });
  process.stdout.write(`${pass ? 'PASS' : 'FAIL'}  ${name}\n      ${detail}\n`);
}

// ── 定位「计」的字节，构造切在它中间的切点 ──
const full = Buffer.from(SSE, 'utf8');
const ji = full.indexOf(Buffer.from('计', 'utf8'));
if (ji < 0) throw new Error('找不到「计」字，测试前提不成立');
process.stdout.write(`「计」= E8 AE A1，位于第 ${ji} 字节\n\n`);

// ── 1) 切在汉字第 1 字节之后：1 + 2 拆分 ──
{
  const chunks = makeChunks(SSE, [ji + 1]);
  const oldOut = parseOld(chunks);
  const newOut = parseNew(chunks);
  process.stdout.write(`切法: [1 字节] + [2 字节]，共 ${chunks.length} 个 chunk\n`);
  check(
    '旧写法在 chunk 边界损坏多字节字符（bug 复现）',
    oldOut.includes('\uFFFD'),
    `旧写法 = ${JSON.stringify(oldOut)}${oldOut.includes('\uFFFD') ? '  ← 含 U+FFFD ✅复现' : '  ← 未损坏'}`,
  );
  check(
    '新写法 StringDecoder 正确还原（修复有效）',
    newOut === SENTENCE,
    `新写法 = ${JSON.stringify(newOut)}  期望 = ${JSON.stringify(SENTENCE)}`,
  );
}

// ── 2) 切在汉字第 2 字节之后：2 + 1 拆分 ──
{
  const chunks = makeChunks(SSE, [ji + 2]);
  check(
    '另一种切法（2+1）同样验证修复',
    parseNew(chunks) === SENTENCE && parseOld(chunks).includes('\uFFFD'),
    `old=${JSON.stringify(parseOld(chunks))} new=${JSON.stringify(parseNew(chunks))}`,
  );
}

// ── 3) 极端：逐字节发送 ──
{
  const pts = [];
  for (let i = 1; i < full.length; i++) pts.push(i);
  const chunks = makeChunks(SSE, pts);
  check(
    '极端：逐字节切分时新写法仍完好',
    parseNew(chunks) === SENTENCE,
    `${chunks.length} 个 chunk → new=${JSON.stringify(parseNew(chunks))}（old 必然碎：${JSON.stringify(parseOld(chunks))}）`,
  );
}

// ── 4) 对照：不切时两者都完好，证明差异确实来自切点 ──
{
  const chunks = makeChunks(SSE, []);
  check(
    '对照：不切分时两种写法都完好（差异确实来自切点）',
    parseOld(chunks) === SENTENCE && parseNew(chunks) === SENTENCE,
    `chunks=${chunks.length} old=${JSON.stringify(parseOld(chunks))} new=${JSON.stringify(parseNew(chunks))}`,
  );
}

const failed = results.filter((r) => !r.pass);
process.stdout.write(`\n${'='.repeat(60)}\n`);
process.stdout.write(failed.length === 0
  ? `全部通过：${results.length}/${results.length}\n`
  : `失败 ${failed.length} 项：${failed.map((f) => f.name).join('; ')}\n`);
process.exitCode = failed.length === 0 ? 0 : 1;
