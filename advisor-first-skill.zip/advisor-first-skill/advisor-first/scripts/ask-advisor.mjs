#!/usr/bin/env node
/**
 * ask-advisor.mjs — 让 DSH 在开工前咨询一个"外部大脑"（默认 GPT-6 Astra）。
 *
 * ── 为什么这么写（2026-10-11 实测根因，不是照抄文档）────────────────────
 * 旧版用「非流式 + effort=max + max_tokens=8000」，出现两类故障：
 *   ① 慢得像挂了：非流式必须等**整段生成完**才返回第一个字节。实测同一个问题
 *      总时长 1.1s–34s 波动，长尾时调用方全程黑屏。
 *   ② 真挂起：短时间内连发（子代理连发 2 次 / 诊断期连发多次）时，中转站
 *      接受连接后不再回数据，进程 CPU≈0 无限等待。
 * 实测证据：
 *   · 无 effort 参数 24/24 成功，TTFT 1.0s
 *   · effort:"max" 流式 TTFT 1.6s（max 本身无害）
 *   · AbortSignal.timeout(5000) 在 5013ms 准时触发（超时机制有效）
 *   · 僵尸进程只在连发场景出现
 *
 * ── 因此本版的设计 ────────────────────────────────────────────────────
 *   1. **默认流式**：TTFT 只有 ~1.6s，能立刻判断服务端是否在干活。
 *   2. **三重看门狗**（全部基于自建 AbortController，不依赖 AbortSignal.timeout）：
 *        · 首字节超时 30s
 *        · 正文停止增长超时 60s —— 每 1 秒轮询检查
 *        · 单次尝试总时长硬上限 120s
 *   3. **有界重试 + 退避**：默认每模型 3 次尝试，退避 1.5s/3s。
 *   4. **模型回退链**：主模型连续失败自动切下一个（astra → sol → luna）。
 *   5. **stderr 有活性**：把进度写 stderr，调用方能看见"还在跑"而不是黑屏。
 *   6. **进程级兜底**：未捕获异常一律 exit=1，绝不留在挂起态。
 *
 * 用法：
 *   node ask-advisor.mjs "你的问题"
 *   node ask-advisor.mjs --prompt-file p.md
 *   node ask-advisor.mjs --model gpt-6-sol --effort high "..."
 *   node ask-advisor.mjs --list | --json | --help
 *   echo "..." | node ask-advisor.mjs -
 *
 * 凭据：ADVISOR_API_KEY / ADVISOR_BASE_URL，否则读 ~/.codex/config.toml。
 * 退出码：0 成功（正文→stdout）；1 失败（原因→stderr）。
 */
import { readFileSync, existsSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { StringDecoder } from 'node:string_decoder';

const CODEX_CONFIG = join(homedir(), '.codex', 'config.toml');
const DEFAULT_TTFT_MS = 30000;    // 首字节上限：实测 ~1.6s（流式），给 30s 极宽松
const DEFAULT_IDLE_MS = 45000;    // 正文停止增长的上限（不是"没字节"）
const DEFAULT_TOTAL_MS = 120000;  // 单次尝试硬上限：实测成功请求 5–40s
const DEFAULT_ATTEMPTS = 3;
const FALLBACK_CHAIN = ['gpt-6-sol', 'gpt-6-luna'];

function parseArgs(argv) {
  const o = { positional: [], json: false, list: false, help: false, quiet: false,
              model: null, effort: null, promptFile: null, attempts: null,
              ttft: null, idle: null, total: null, out: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--json') o.json = true;
    else if (a === '--list') o.list = true;
    else if (a === '--quiet') o.quiet = true;
    else if (a === '--help' || a === '-h') o.help = true;
    else if (a === '--model') o.model = argv[++i];
    else if (a === '--effort') o.effort = argv[++i];
    else if (a === '--prompt-file') o.promptFile = argv[++i];
    else if (a === '--attempts') o.attempts = Number(argv[++i]);
    else if (a === '--ttft-ms') o.ttft = Number(argv[++i]);
    else if (a === '--idle-ms') o.idle = Number(argv[++i]);
    else if (a === '--total-ms') o.total = Number(argv[++i]);
    else if (a === '--out') o.out = argv[++i];
    else o.positional.push(a);
  }
  return o;
}

const USAGE = `用法：
  node ask-advisor.mjs "你的问题"
  node ask-advisor.mjs --prompt-file 提示词.md
  node ask-advisor.mjs --model gpt-6-sol --effort high "问题"
  node ask-advisor.mjs --list                列出可用模型
选项：
  --model <id>       默认 gpt-6-astra（失败自动回退 ${FALLBACK_CHAIN.join(' → ')}）
  --effort <e>       off | low | high | max（默认 max）
  --prompt-file <f>  从文件读提示词
  --out <f>          把正文同时写一份到文件
  --json             输出含 usage 的 JSON
  --quiet            不往 stderr 写进度
  --attempts <n>     每个模型尝试次数，默认 ${DEFAULT_ATTEMPTS}
  --ttft-ms <n>      首字节超时，默认 ${DEFAULT_TTFT_MS}
  --idle-ms <n>      数据块间空闲超时，默认 ${DEFAULT_IDLE_MS}
  --total-ms <n>     总时长硬上限，默认 ${DEFAULT_TOTAL_MS}
`;

/**
 * 从 ~/.codex/config.toml 读 **当前生效的 model_providers 块**。
 *
 * ⚠️ 不能只匹配文件里第一个 base_url / experimental_bearer_token：
 * 该文件可以同时存在多个 provider 块（本机就有 [model_providers.fox] 和
 * [model_providers.custom]），谁在前谁在后取决于文件结构，随便抓一个会拿错凭据。
 * 这里只认 `model_provider = "<name>"` 指向的那个块。
 */
function readCodexProvider() {
  const r = { token: null, baseUrl: null, provider: null };
  if (!existsSync(CODEX_CONFIG)) return r;
  let t;
  try { t = readFileSync(CODEX_CONFIG, 'utf8'); } catch { return r; }

  const active = t.match(/^\s*model_provider\s*=\s*"([^"]+)"/m);
  if (!active) return r;
  r.provider = active[1];

  const esc = active[1].replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const sec = t.match(new RegExp(`\\[model_providers\\.${esc}\\]([\\s\\S]*?)(?=\\n\\[|$)`));
  if (!sec) return r;
  const body = sec[1];

  const tok = body.match(/experimental_bearer_token\s*=\s*"([^"]+)"/);
  if (tok) r.token = tok[1];
  const base = body.match(/base_url\s*=\s*"([^"]+)"/);
  if (base) r.baseUrl = base[1];
  return r;
}

/**
 * 从 DSH 的凭据文件补一个兜底来源。
 * 加这一层的理由：key 本来就在这台机器上，工具却只认环境变量，
 * 等于把"去找 key 并 export"的麻烦推给用户。YAML 结构固定（refs: 下一层 key: value），
 * 用最小解析即可，不引入 js-yaml 依赖。
 * 注意：这里只认字面名字就是该服务名的 key，不存在张冠李戴。
 */
function readCredentialRef(name) {
  const p = join(homedir(), '.dsh-beta', '.credentials.yaml');
  if (!existsSync(p)) return null;
  let t;
  try { t = readFileSync(p, 'utf8'); } catch { return null; }
  const refs = t.match(/^refs:\s*\n([\s\S]*?)(?=\n\S|$)/m);
  if (!refs) return null;
  const m = refs[1].match(new RegExp(`^\\s*${name}:\\s*(\\S+)\\s*$`, 'm'));
  return m ? m[1] : null;
}

async function readStdin() {
  const chunks = [];
  for await (const c of process.stdin) chunks.push(c);
  return Buffer.concat(chunks).toString('utf8');
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

class AttemptError extends Error {
  constructor(msg, retryable = true) {
    super(msg);
    this.retryable = retryable;
  }
}

/**
 * 单次流式调用，带三重看门狗。
 * 返回 { reply, usage, ttftMs, totalMs }。
 */
async function streamOnce({ base, token, model, system, prompt, effort, ttftMs, idleMs, totalMs, onProgress }) {
  const ac = new AbortController();
  let abortReason = null;
  const t0 = Date.now();

  let ttftTimer = setTimeout(() => {
    if (abortReason === null) { abortReason = `首字节超过 ${ttftMs}ms 未到达`; ac.abort(); }
  }, ttftMs);
  let idleTimer = null;
  const totalTimer = setTimeout(() => {
    if (abortReason === null) { abortReason = `总时长超过 ${totalMs}ms`; ac.abort(); }
  }, totalMs);
  // idleTimer 是 setInterval，必须用 clearInterval 清（Node 里两者 ID 空间相同、
  // 互换也能跑，但不依赖这种隐式行为）。置 null 以便重复调用安全。
  const clearAll = () => {
    clearTimeout(ttftTimer);
    if (idleTimer) { clearInterval(idleTimer); idleTimer = null; }
    clearTimeout(totalTimer);
  };

  const body = {
    model,
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: prompt },
    ],
    reasoning_effort: effort,
    max_tokens: 8000,
    stream: true,
  };

  try {
    const res = await fetch(`${base}/chat/completions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: ac.signal,
    });

    if (!res.ok) {
      const text = await res.text();
      clearAll();
      const retryable = res.status >= 500 || res.status === 429;
      throw new AttemptError(`HTTP ${res.status} ${text.slice(0, 300)}`, retryable);
    }

    // 首字节到了 —— 关掉 TTFT 计时，改用「有效内容」空闲看门狗
    const ttft = Date.now() - t0;
    clearTimeout(ttftTimer);
    ttftTimer = null;

    let buf = '';
    let reply = '';
    let usage = null;
    let emitted = 0;
    let lastByteAt = Date.now();    // 收到任意字节的时刻（含保活心跳）
    let lastContentAt = Date.now(); // 正文真正变长的时刻 ← 看门狗依据
    const decoder = new StringDecoder('utf8');  // 跨 chunk 拼多字节字符，见下方说明

    /**
     * 看门狗：每 1 秒检查一次「正文是否还在增长」。
     *
     * ⚠️ 判据必须是**正文增长**，绝不能是「收到字节」。实测教训（2026-10-11）：
     * 中转站会持续发 SSE 保活心跳，按字节重置的话超时永远不触发 ——
     * 实测某请求首字节 11.9s 就到了，随后靠心跳硬撑满 240s 总超时才被杀。
     * 同时保留 lastByteAt，用于在超时时区分「纯心跳」与「真卡死」。
     */
    idleTimer = setInterval(() => {
      if (abortReason !== null) return;
      const silentMs = Date.now() - lastContentAt;
      if (silentMs > idleMs) {
        const sinceByte = Date.now() - lastByteAt;
        const onlyHeartbeat = sinceByte < silentMs / 2;
        abortReason = `正文停止增长 ${silentMs}ms（上限 ${idleMs}ms）` +
          (onlyHeartbeat ? `，但 ${sinceByte}ms 前仍有字节到达 = 只有保活心跳，没有真实内容` : '，且无任何字节到达');
        clearInterval(idleTimer);
        idleTimer = null;
        ac.abort();
      }
    }, 1000);

    onProgress?.(`首字节 ${ttft}ms，开始接收…`);

    for await (const chunk of res.body) {
      lastByteAt = Date.now();
      // ⚠️ 必须用 StringDecoder，不能 Buffer.from(chunk).toString('utf8')。
      // 后者对每个 chunk 独立解码：一个中文字符占 3 字节，被 TCP 分片切开时
      // 前半截解码失败就变成 U+FFFD（实测「计算阶乘」的"计"字被吃成 \uFFFD，
      // 而且这个损坏会一路写进 --out 文件，不是显示问题）。
      buf += decoder.write(chunk);

      let nl;
      while ((nl = buf.indexOf('\n')) !== -1) {
        const line = buf.slice(0, nl).trim();
        buf = buf.slice(nl + 1);
        if (!line.startsWith('data:')) continue;
        const data = line.slice(5).trim();
        if (data === '[DONE]') continue;
        let j;
        try { j = JSON.parse(data); } catch { continue; }
        const delta = j.choices?.[0]?.delta?.content;
        if (typeof delta === 'string' && delta) {
          reply += delta;
          emitted++;
          lastContentAt = Date.now();          // ← 只有真正产出内容才续命
          if (emitted % 60 === 0) onProgress?.(`已接收约 ${reply.length} 字…`);
        }
        if (j.usage) usage = j.usage;
      }
    }

    clearAll();
    if (!reply.trim()) throw new AttemptError('流结束了但正文为空（可能是 reasoning 占满了 max_tokens）', true);
    return { reply, usage, ttftMs: ttft, totalMs: Date.now() - t0 };
  } catch (e) {
    clearAll();
    if (abortReason !== null) throw new AttemptError(`看门狗触发：${abortReason}`, true);
    if (e instanceof AttemptError) throw e;
    throw new AttemptError(`${e?.name || 'Error'}: ${e?.message || e}`, true);
  }
}

async function listModels(base, token) {
  const r = await fetch(`${base}/models`, { headers: { Authorization: `Bearer ${token}` } });
  if (!r.ok) throw new Error(`GET /models 失败 (${r.status}) ${(await r.text()).slice(0, 300)}`);
  const j = await r.json();
  return (j.data || []).map((m) => m.id).sort();
}

function fail(msg) {
  process.stderr.write(`ask-advisor: ${msg}\n`);
  process.exitCode = 1;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) { process.stdout.write(USAGE); return; }

  // ─────────────────────────────────────────────────────────────
  // 顺序：**先解析参数与提示词，再检查凭据**。
  // 反例（本文件曾犯过）：凭据检查在最前时，`ask-advisor.mjs`（空提示词）和
  // `--prompt-file 不存在的文件` 都会先报「找不到 API key」，exit=1 虽对但
  // 原因全错，用户无法判断自己错在哪一步。参数类错误必须优先于环境类错误。
  // 例外：--list 不需要提示词。
  // ─────────────────────────────────────────────────────────────
  const cfg = readCodexProvider();
  const base = (process.env.ADVISOR_BASE_URL || cfg.baseUrl || '').replace(/\/+$/, '');
  const effort = args.effort || process.env.ADVISOR_EFFORT || 'max';
  const primary = args.model || process.env.ADVISOR_MODEL || 'gpt-6-astra';
  const attempts = Math.max(1, args.attempts || DEFAULT_ATTEMPTS);
  const ttftMs = args.ttft || DEFAULT_TTFT_MS;
  const idleMs = args.idle || DEFAULT_IDLE_MS;
  const totalMs = args.total || DEFAULT_TOTAL_MS;

  let prompt = null;
  if (!args.list) {
    prompt = args.positional.join(' ').trim();
    if (args.promptFile) {
      if (!existsSync(args.promptFile)) return fail(`提示词文件不存在：${args.promptFile}`);
      prompt = readFileSync(args.promptFile, 'utf8');
    }
    if (!prompt || prompt === '-') {
      const piped = (await readStdin()).trim();
      if (piped) prompt = piped;
    }
    if (!prompt) return fail(`没有提示词\n${USAGE}`);
  }

  // ── 凭据解析：三档，且每档都要说明来源 ──
  // ① 环境变量 ADVISOR_API_KEY → ② ~/.dsh-beta/.credentials.yaml → ③ codex 配置
  // 第 ③ 档只在「它的 base_url 与本次要用的端点指向同一服务」时才允许，
  // 否则就是拿 A 家令牌打 B 家端点，只会换来 401 并把真因藏起来。
  let token = process.env.ADVISOR_API_KEY || null;
  let tokenFrom = token ? '环境变量 ADVISOR_API_KEY' : null;

  if (!token) {
    const fromRefs = readCredentialRef('ADVISOR_API_KEY');
    if (fromRefs) { token = fromRefs; tokenFrom = '~/.dsh-beta/.credentials.yaml'; }
  }

  if (!token && cfg.token) {
    // codex 的令牌只在其服务与当前端点一致时可用
    const sameService = cfg.baseUrl && base && cfg.baseUrl.replace(/\/+$/, '') === base;
    if (sameService) {
      token = cfg.token;
      tokenFrom = `~/.codex/config.toml [model_providers.${cfg.provider}]`;
    }
  }

  if (!token) {
    const hints = [];
    if (cfg.baseUrl) {
      hints.push(`~/.codex/config.toml 的当前 provider「${cfg.provider}」指向 ${cfg.baseUrl}，与本次端点 ${base || '(未设)'} 不是同一服务，其令牌不可用`);
    }
    hints.push('请任选一种方式提供凭据：');
    hints.push('  1) 设置环境变量：$env:ADVISOR_API_KEY = "..."');
    hints.push('  2) 写入 ~/.dsh-beta/.credentials.yaml 的 refs.ADVISOR_API_KEY');
    hints.push(`  3) 让 ADVISOR_BASE_URL 与 ~/.codex/config.toml 中 provider 的 base_url 指向同一服务`);
    return fail('找不到可用的 API key\n  · ' + hints.join('\n  · '));
  }

  const note = (s) => { if (!args.quiet) process.stderr.write(`[advisor] ${s}\n`); };
  // 凭据来自哪里必须可见，否则用户无法判断自己正在用谁的身份
  note(`端点=${base} 凭据来源=${tokenFrom}`);

  if (args.list) {
    try {
      process.stdout.write((await listModels(base, token)).join('\n') + '\n');
    } catch (e) { return fail(e.message); }
    return;
  }

  const system = [
    '你是一位资深技术顾问，负责在动手之前给出方案。',
    '要求：直接给可执行的结论，不要客套，不要复述问题。',
    '如果信息不足，明确列出你需要的关键信息，但仍要先给出基于现有信息的最佳方案。',
    '对不确定的地方必须显式标注"不确定"，禁止编造事实、路径、命令或 API。',
  ].join('\n');

  const chain = [primary, ...FALLBACK_CHAIN].filter((m, i, a) => a.indexOf(m) === i);
  const failures = [];
  let attemptNo = 0;

  for (let ci = 0; ci < chain.length; ci++) {
    const model = chain[ci];
    for (let i = 0; i < attempts; i++) {
      attemptNo++;
      note(`尝试 ${attemptNo}：model=${model} effort=${effort}（TTFT≤${ttftMs} idle≤${idleMs} total≤${totalMs}）`);
      try {
        const r = await streamOnce({
          base, token, model, system, prompt, effort, ttftMs, idleMs, totalMs,
          onProgress: (s) => note(`  ${s}`),
        });
        note(`成功：model=${model} ttft=${r.ttftMs}ms total=${r.totalMs}ms${r.usage ? ` usage=${JSON.stringify(r.usage)}` : ''}`);

        if (args.out) {
          try { writeFileSync(args.out, r.reply); note(`正文已另存 ${args.out}`); }
          catch (e) { note(`写 --out 失败：${e.message}`); }
        }

        if (args.json) {
          process.stdout.write(JSON.stringify({ model, effort, attempts: attemptNo, ...r }, null, 2) + '\n');
        } else {
          process.stdout.write(r.reply.trimEnd() + '\n');
        }
        return;
      } catch (e) {
        const msg = e?.message || String(e);
        failures.push(`${model} 第${i + 1}次: ${msg}`);
        note(`失败：${msg}`);
        if (e instanceof AttemptError && e.retryable === false) {
          note('该类错误不可重试，跳到下一个模型');
          break;
        }
        if (i < attempts - 1) await sleep(1500 * (i + 1));
      }
    }
    if (ci < chain.length - 1) note(`模型 ${model} 未成功，回退到 ${chain[ci + 1]}`);
  }

  fail(`全部尝试失败（共 ${attemptNo} 次）\n  - ` + failures.join('\n  - '));
}

main().catch((e) => fail(`未预期错误：${e && e.stack ? e.stack : e}`));
