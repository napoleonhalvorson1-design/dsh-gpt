# advisor-first 安装指南

## 🎯 快速安装 (1分钟)

```powershell
# 1. 进入下载的目录
cd advisor-first-skill

# 2. 运行安装脚本
pwsh -File .\install.ps1

# 3. 验证安装
# 在DSH中输入: /advisor-first
```

完成！

---

## 📋 安装详情

### 安装位置

```
~\.dsh-beta\skills\advisor-first\
  ├── SKILL.md              # 技能定义
  └── scripts\
      └── ask-advisor.mjs   # 核心脚本
```

### 安装脚本做什么

1. **检查目标目录** - `~\.dsh-beta\skills\`
2. **备份旧版本** - 如果存在，重命名为 `advisor-first.backup.<timestamp>`
3. **复制文件** - 将 `advisor-first\` 目录复制到技能目录
4. **SHA256校验** - 验证每个文件完整性
5. **立即生效** - DSH使用Chokidar监视，无需重启

### 安装要求

- ✅ PowerShell 5.1+ (Windows自带) 或 PowerShell 7+
- ✅ Node.js v18+ (用于运行脚本)
- ✅ DSH已安装在 `~\.dsh-beta\`

---

## ⚙️ 配置

### 最简配置 (推荐)

在 `~\.dsh-beta\.credentials.yaml` 添加:

```yaml
refs:
  ADVISOR_API_KEY: sk-your-api-key-here
```

完成！脚本会自动读取。

### 或使用环境变量

```powershell
# 临时设置 (当前会话)
$env:ADVISOR_API_KEY = "sk-your-api-key-here"

# 永久设置 (需要管理员权限)
[System.Environment]::SetEnvironmentVariable(
    "ADVISOR_API_KEY",
    "sk-your-api-key-here",
    "User"
)
```

### 高级配置

如果需要自定义端点:

```powershell
$env:ADVISOR_BASE_URL = "https://your-api.com/v1"
$env:ADVISOR_MODEL = "gpt-6-astra"
$env:ADVISOR_EFFORT = "max"
```

或在 `~\.codex\config.toml`:

```toml
model_provider = "custom"

[model_providers.custom]
base_url = "https://your-api.com/v1"
experimental_bearer_token = "sk-your-api-key-here"
```

**注意**: codex配置仅当base_url与ADVISOR_BASE_URL匹配时使用。

---

## ✅ 验证安装

### 方法1: 在DSH中测试

```
输入: /advisor-first
期望: 看到skill内容注入
```

### 方法2: 直接运行脚本

```powershell
# 列出可用模型
node ~\.dsh-beta\skills\advisor-first\scripts\ask-advisor.mjs --list

# 期望输出:
# [advisor] 端点=https://... 凭据来源=...
# gpt-6-astra
# gpt-6-luna
# gpt-6-sol
# ...
# (exit code = 0)
```

### 方法3: 快速测试

```powershell
node ~\.dsh-beta\skills\advisor-first\scripts\ask-advisor.mjs --quiet "只回复两个字:在吗"

# 期望: 1-2秒内返回 "在吗" (exit code = 0)
```

---

## 🧪 运行测试

```powershell
cd ~\.dsh-beta\skills\advisor-first

# 完整测试 (需要网络)
node tests\run-tests.mjs

# 离线测试
$env:SKIP_NETWORK = "1"
node tests\run-tests.mjs

# 期望: "✓ 全部通过: 8/8" (exit code = 0)
```

---

## 🔧 常见安装问题

### Q: 提示"找不到 .dsh-beta 目录"

A: DSH未安装或安装在非标准位置
```powershell
# 检查DSH安装
Test-Path ~\.dsh-beta\

# 如果返回False，先安装DSH
```

### Q: 安装完成但 /advisor-first 无效

A: 可能的原因:

1. **DSH未重新扫描** - 重启DSH或等待几秒
2. **拼写错误** - 确保输入 `/advisor-first` (带斜杠)
3. **目录结构错误** - 检查是否为:
   ```
   ~\.dsh-beta\skills\advisor-first\SKILL.md
   ```

### Q: 提示"找不到 API key"

A: 凭据未配置

```powershell
# 快速修复: 设置环境变量
$env:ADVISOR_API_KEY = "sk-your-key"

# 或写入配置文件 (推荐)
# 编辑: ~\.dsh-beta\.credentials.yaml
```

### Q: SHA256校验失败

A: 文件传输过程中损坏

```powershell
# 重新下载advisor-first-skill
# 然后重新运行 install.ps1
```

### Q: PowerShell执行策略错误

A: 
```powershell
# 临时允许运行脚本
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

# 然后重新运行
pwsh -File .\install.ps1
```

---

## 🔄 更新到新版本

```powershell
# 1. 进入新版本目录
cd advisor-first-skill-new

# 2. 运行安装脚本 (会自动备份旧版本)
pwsh -File .\install.ps1

# 3. 验证
node ~\.dsh-beta\skills\advisor-first\tests\run-tests.mjs
```

旧版本会自动备份为 `advisor-first.backup.<timestamp>`

---

## 🗑️ 卸载

```powershell
# 删除技能目录
Remove-Item -Recurse ~\.dsh-beta\skills\advisor-first

# 可选: 清理环境变量
Remove-Item Env:\ADVISOR_API_KEY
Remove-Item Env:\ADVISOR_BASE_URL
Remove-Item Env:\ADVISOR_MODEL
Remove-Item Env:\ADVISOR_EFFORT

# 可选: 清理credentials.yaml中的条目
# 手动编辑: ~\.dsh-beta\.credentials.yaml
```

---

## 📦 手动安装

如果自动安装失败，可以手动安装:

```powershell
# 1. 创建目标目录
New-Item -ItemType Directory -Force -Path ~\.dsh-beta\skills\advisor-first

# 2. 复制SKILL.md
Copy-Item .\advisor-first\SKILL.md ~\.dsh-beta\skills\advisor-first\

# 3. 创建scripts目录
New-Item -ItemType Directory -Force -Path ~\.dsh-beta\skills\advisor-first\scripts

# 4. 复制脚本
Copy-Item .\advisor-first\scripts\ask-advisor.mjs ~\.dsh-beta\skills\advisor-first\scripts\

# 5. 验证
Test-Path ~\.dsh-beta\skills\advisor-first\SKILL.md
Test-Path ~\.dsh-beta\skills\advisor-first\scripts\ask-advisor.mjs
```

---

## 🎓 安装后的下一步

1. **阅读SKILL.md** - 完整的使用指南
   ```powershell
   code ~\.dsh-beta\skills\advisor-first\SKILL.md
   ```

2. **准备提示词模板** - 创建你的第一个问题
   ```powershell
   @"
   # 背景
   - 环境: Windows 11, Node.js v20
   
   # 目标
   测试advisor-first是否工作正常
   
   # 我目前的判断
   - 我打算: 发送一个简单问题测试
   - 我担心: 配置可能不正确
   
   # 请回答
   1. 收到这条消息了吗？
   2. 你是哪个模型？
   "@ | Out-File -Encoding utf8 test-question.md
   ```

3. **第一次调用**
   ```powershell
   node ~\.dsh-beta\skills\advisor-first\scripts\ask-advisor.mjs `
     --prompt-file test-question.md `
     --out test-answer.md
   
   # 查看回答
   cat test-answer.md
   ```

4. **在DSH中使用**
   - 在DSH对话中输入 `/advisor-first`
   - 按照注入的说明准备提示词
   - 调用脚本获取建议

---

## 📞 获取帮助

如果遇到问题:

1. **查看详细文档** - `README.md` 和 `SKILL.md`
2. **运行诊断测试** - `node tests\run-tests.mjs`
3. **检查stderr输出** - 包含详细的错误信息和凭据来源
4. **使用探针命令** - `--list` 测试连接和凭据

---

## ✨ 完成

安装成功后，你可以:

- ✅ 在DSH中使用 `/advisor-first` 激活技能
- ✅ 直接运行 `ask-advisor.mjs` 脚本
- ✅ 在复杂任务前咨询GPT-6 Astra获取方案
- ✅ 获得外部视角，降低返工率

**下一步**: 阅读 `README.md` 了解何时使用、如何编写提示词、最佳实践等。
