# advisor-first 实战示例

真实场景下如何使用advisor-first技能。

---

## 示例1: API性能优化 (技术选型)

### 场景
用户: "我的API很慢，P95响应时间500ms，能优化到200ms吗？"

### 判断: ✅ 需要咨询
- 涉及技术选型(缓存、数据库、架构)
- 可能需要修改多个模块
- 有明确的性能指标要求

### 提示词文件 (`api-optimization.md`)

```markdown
# 背景(本机已验证的事实)
- 环境: Node.js v20.11, Express 4.18, PostgreSQL 14
- 已知事实: 
  * P95响应时间 500ms (实测100次请求)
  * 数据库查询占用约80%时间 (用pg-monitor测量)
  * 单表数据量: users表100万行
  * 查询类型: JOIN查询，关联3张表
  * 当前索引: 仅主键有索引

# 目标
将API P95响应时间从500ms降到200ms以内

# 约束(硬性限制)
- 不能更换框架(Express必须保留)
- 不能修改数据库schema(生产环境有数据)
- 2小时内完成优化
- 预算有限，不能上云服务

# 我目前的判断(要求你反驳)
- 我打算: 加Redis缓存整个查询结果，TTL设30秒
- 我担心: 
  1. 缓存失效策略可能很复杂
  2. 30秒TTL可能导致数据不一致
  3. 没考虑数据库层面的优化

# 请回答
1. Redis缓存是最优解吗？考虑到2小时时间限制
2. 数据库索引优化能否达到目标？如果能，应该加在哪些列？
3. 是否有更简单的quick win方案？
4. 如果用缓存，失效策略应该怎么设计？

要求: 直接给结论，优先级从高到低排序。
信息不足处标注"不确定"，禁止编造配置项。
```

### 调用脚本

```bash
node ~/.dsh-beta/skills/advisor-first/scripts/ask-advisor.mjs \
  --prompt-file api-optimization.md \
  --out api-optimization-reply.md
```

### 评估建议 (`api-optimization-reply.md`)

顾问建议：
1. **优先加索引** - JOIN的外键列没索引，这是主要瓶颈
2. **其次查询优化** - 用EXPLAIN分析，可能可以减少JOIN
3. **最后考虑缓存** - 如果前两步不够再加

### 决策记录

```markdown
## 顾问咨询结果

**问题**: API P95从500ms优化到200ms

**顾问建议**: 
1. 先加数据库索引(外键列)
2. 优化SQL查询(减少不必要的JOIN)
3. 索引+查询优化不够再考虑缓存

**我的决策**:
- ✅ 采纳索引建议: 先加外键索引，这是无风险的quick win
- ✅ 采纳EXPLAIN分析: 用`EXPLAIN ANALYZE`看实际执行计划
- ❌ 暂不采纳缓存: 先试索引，不够再加缓存
- ⚠️ 需验证: 检查users表和关联表的实际schema和索引情况

**执行计划**:
1. 读取数据库迁移文件，确认当前索引
2. 用EXPLAIN ANALYZE分析慢查询
3. 根据执行计划添加索引
4. 重测P95响应时间
5. 如果不到200ms，再考虑其他方案

**错了的代价**: 
- 索引添加是增量的，可以安全回滚
- 最坏情况是索引没帮助，损失30分钟
```

### 执行

```bash
# 1. 读取schema
Read(file_path="db/schema.sql")

# 2. 检查现有索引
Bash(command="psql -d mydb -c '\\d users'")

# 3. 分析慢查询
Bash(command="psql -d mydb -c 'EXPLAIN ANALYZE SELECT ...'")

# 4. 添加索引
Edit(file_path="db/migrations/add_indexes.sql", ...)

# 5. 执行迁移并测试
Bash(command="npm run migrate")
Bash(command="npm run benchmark")
```

---

## 示例2: 同一问题失败2次 (调试)

### 场景
用户: "为什么CI通过但本地失败？我已经重装node_modules了。"

### 判断: ✅ 需要咨询
- 已尝试修复1次(重装依赖)仍失败
- 根因不明确
- CI/本地环境差异属于复杂问题

### 提示词文件 (`ci-local-diff.md`)

```markdown
# 背景(本机已验证的事实)
- 环境: 
  * 本地: Windows 11, Node.js v20.11.0, npm 10.2.4
  * CI: GitHub Actions, ubuntu-latest, Node.js v20.x
- 已知事实:
  * CI输出: "✓ 23 tests passed" (exit=0)
  * 本地错误: "ENOENT: no such file or directory, open '../dist/index.js'"
  * 错误位置: tests/integration.test.js:12
  * 实测: dist/目录存在，dist/index.js也存在
- 已尝试方案:
  1. 删除node_modules，重新npm install → 仍失败
  2. 检查.gitignore，dist/不在忽略列表 → 仍失败

# 目标
找出CI成功本地失败的根本原因，让本地也能通过

# 约束(硬性限制)
- 不能修改CI配置(团队共用)
- 不能要求团队成员也改环境
- 必须在Windows上工作

# 我目前的判断(要求你反驳)
- 我打算: 对比CI和本地的环境变量
- 我担心:
  1. 可能是路径分隔符问题(Windows用反斜杠)
  2. 可能是相对路径解析不同
  3. 可能是dist/index.js根本不是问题点

# 请回答
1. '../dist/index.js'在Windows上为何找不到？有哪些可能原因？
2. 如何系统地排查CI/本地环境差异？
3. 路径分隔符问题通常怎么解决？
4. 还有哪些常见的"CI过本地不过"的坑？

要求: 给出可操作的排查步骤，不要泛泛建议"检查环境"。
```

### 调用脚本

```bash
node ~/.dsh-beta/skills/advisor-first/scripts/ask-advisor.mjs \
  --prompt-file ci-local-diff.md \
  --out ci-local-diff-reply.md
```

### 评估建议

顾问建议：
1. **检查工作目录** - 测试运行时的cwd可能不同
2. **路径拼接方式** - '../dist' 可能在不同环境解析不同
3. **构建步骤** - 本地是否运行了npm run build
4. **用path.join替代字符串拼接**

### 决策记录

```markdown
## 顾问咨询结果

**问题**: CI通过本地失败，ENOENT '../dist/index.js'

**顾问建议**:
1. 检查测试运行时的cwd(process.cwd())
2. 检查本地是否执行了构建步骤
3. 用path.join()替代字符串路径拼接
4. 在测试前加console.log打印文件实际路径

**我的决策**:
- ✅ 立即执行: console.log(process.cwd())看工作目录
- ✅ 验证构建: 检查package.json的test脚本是否含build
- ✅ 检查文件存在: 用fs.existsSync在测试前验证
- ⚠️ 暂缓path.join: 先找到根因，再决定是否改代码

**执行计划**:
1. 读取tests/integration.test.js第12行
2. 读取package.json的scripts.test
3. 在测试文件里加调试输出(cwd, 文件路径, existsSync)
4. 本地运行npm test，看调试输出
5. 对比CI日志，找出差异点

**错了的代价**: 加调试代码是安全的，最多浪费10分钟
```

---

## 示例3: 用户要做成熟软件 (架构设计)

### 场景
用户: "帮我做个任务管理系统，要支持多人协作。"

### 判断: ✅ 需要咨询
- "做个X"场景，X是成熟软件类别
- 涉及多个领域(前端、后端、数据库、认证)
- 需要架构决策

### 提示词文件 (`task-system.md`)

```markdown
# 背景(本机已验证的事实)
- 环境: 用户熟悉Node.js和React
- 已知事实:
  * 用户是solo开发者，没有团队
  * 预计开发时间: 1-2周
  * 目标用户: 10-50人的小团队
  * 部署预算: $10/月以内

# 目标
搭建一个多人协作的任务管理系统(类Trello简化版)

# 约束(硬性限制)
- 必须用Node.js后端(用户最熟悉)
- 必须用React前端(用户最熟悉)
- 1-2周内完成MVP(看板、任务卡、多用户)
- 低成本部署($10/月以内)

# 我目前的判断(要求你反驳)
- 我打算:
  * 后端: Express + MongoDB + JWT认证
  * 前端: Create React App + Redux + Material-UI
  * 部署: Vercel(前端) + Railway(后端+数据库)
- 我担心:
  1. Redux可能太重，1-2周学习成本高
  2. MongoDB可能不需要，关系型数据库更简单
  3. 实时协作(多人同时看一个看板)不知道怎么实现

# 请回答
1. 这个技术栈对1-2周时间线是否合理？
2. Redux对小项目是否过度设计？有更简单的状态管理吗？
3. MongoDB vs PostgreSQL，哪个更适合任务管理系统？
4. 实时协作推荐用WebSocket还是简单的轮询？
5. 还有哪些容易忽略但重要的功能点？

要求: 优先考虑"快速完成MVP"，不要过度设计。
给出具体的库推荐(不要说"选一个状态管理库")。
```

### 调用脚本

```bash
node ~/.dsh-beta/skills/advisor-first/scripts/ask-advisor.mjs \
  --prompt-file task-system.md \
  --out task-system-reply.md
```

### 评估建议

顾问建议：
1. **状态管理**: 用React Context或Zustand，不要Redux
2. **数据库**: PostgreSQL更适合(任务、用户、权限都是关系型)
3. **实时**: MVP先用轮询(每5秒)，够用再上WebSocket
4. **认证**: 用成熟库(Passport.js)，别手写JWT逻辑
5. **MVP功能**: 看板、任务、分配、状态，别加评论、附件、通知

### 决策记录

```markdown
## 顾问咨询结果

**问题**: 1-2周搭建任务管理系统MVP

**顾问建议**:
- 状态管理: Zustand (比Redux简单10倍)
- 数据库: PostgreSQL (关系型更适合权限模型)
- 实时: 先轮询(5秒)，足够用
- 认证: Passport.js (成熟方案)
- MVP范围: 看板+任务+分配+状态，其他v2再说

**我的决策**:
- ✅ 采纳Zustand: 查文档确认学习曲线
- ✅ 采纳PostgreSQL: 用户权限确实是关系型
- ✅ 采纳轮询方案: MVP够用，简单
- ✅ 采纳Passport.js: 不重复造轮子
- ✅ 采纳功能范围: 严格控制MVP范围

**执行计划**:
1. 创建项目结构(前端+后端)
2. 设计数据库schema(users, boards, tasks)
3. 实现认证(注册、登录、会话)
4. 实现看板CRUD
5. 实现任务CRUD和拖拽排序
6. 实现轮询刷新机制
7. 部署到Vercel+Railway

**错了的代价**:
- Zustand学习失败: 回退到Context API (1天)
- 轮询不够用: 加WebSocket (2天)
- 范围失控: 2周变4周 → 严格按MVP执行
```

---

## 示例4: 不熟悉的技术领域 (学习新技术)

### 场景
用户: "用Rust写一个命令行工具，解析CSV文件。"
DeepSeek内心: 我对Rust不够熟悉，特别是错误处理和生命周期。

### 判断: ✅ 需要咨询
- 不熟悉的技术领域(Rust)
- 涉及语言特性(错误处理、生命周期)

### 提示词文件 (`rust-csv-tool.md`)

```markdown
# 背景(本机已验证的事实)
- 环境: Rust 1.75, cargo已安装
- 已知事实:
  * CSV格式: 标准CSV，逗号分隔，有表头
  * 预期数据量: 10MB以内
  * 需要输出: JSON格式
  * 我对Rust: 了解基础语法，但错误处理和生命周期不熟

# 目标
写一个Rust命令行工具，读取CSV，输出JSON

# 约束(硬性限制)
- 必须用Rust(用户要求)
- 要有合理的错误处理
- 代码要符合Rust惯用法

# 我目前的判断(要求你反驳)
- 我打算:
  * 用csv crate读取文件
  * 用serde_json序列化成JSON
  * 用Result<T, Box<dyn Error>>处理所有错误
- 我担心:
  1. Box<dyn Error>是否是惯用法？
  2. 文件读取要不要用BufReader？
  3. 生命周期会不会很复杂？
  4. 如何优雅地处理CSV解析失败？

# 请回答
1. 错误处理的惯用法是什么？Box<dyn Error>还是自定义Error enum？
2. 10MB文件需要BufReader吗？
3. 生命周期在这个场景会是问题吗？
4. 给一个符合Rust惯用法的代码结构大纲？

要求: 给出具体的crate名称和版本建议。
如果有常见坑，请明确指出。
```

### 调用脚本

```bash
node ~/.dsh-beta/skills/advisor-first/scripts/ask-advisor.mjs \
  --prompt-file rust-csv-tool.md \
  --out rust-csv-tool-reply.md
```

---

## 关键要点总结

### ✅ 好的提示词特征

1. **具体的背景** - 包含版本号、实测数据、环境细节
2. **明确的约束** - 说清楚不能改什么、必须用什么
3. **当前判断** - 说出你打算怎么做、担心什么
4. **具体问题** - 不要问"怎么做"，要问"A方案vs B方案"
5. **实测数据** - 用数字而非推测(500ms不是"很慢")

### ❌ 差的提示词特征

1. 泛泛而谈 - "我想优化性能" → 哪个性能？当前多少？目标多少？
2. 没有约束 - 顾问会给出你无法采纳的方案
3. 没有当前判断 - 得到教科书式的答案，没有增量
4. 问题太宽泛 - "有什么建议？" → 得到清单式的废话

### 📋 决策记录要素

每次咨询后必须记录：

1. **问题** - 一句话总结咨询什么
2. **建议** - 顾问说了什么(核心1-3点)
3. **决策** - 采纳/拒绝什么，为什么
4. **验证** - 哪些信息需要核实
5. **计划** - 接下来要做什么
6. **代价** - 如果错了最坏是什么

---

## 更多示例场景

- **数据库迁移方案** - PostgreSQL版本升级，零停机方案
- **安全漏洞修复** - SQL注入，要不要上ORM
- **性能瓶颈定位** - CPU 100%，不知道是哪部分代码
- **部署策略选择** - Docker vs Serverless，成本与复杂度权衡
- **测试策略** - E2E vs 单元测试，覆盖率目标

**共同点**: 都涉及决策、权衡、选型，而不是简单的"改这一行代码"。
