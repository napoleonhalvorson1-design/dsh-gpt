#Requires -Version 7
<#
.SYNOPSIS
  合并安装：把本包的**文档增量**装进已存在的 advisor-first 技能，绝不覆盖技能本体。

.DESCRIPTION
  背景（2026-10-11 实测，证据在下面每一条都能复算）：
    · 本包 advisor-first\scripts\ask-advisor.mjs 的 SHA256 =
      62328A4D4214295F...（与已装技能、与原版工具包的脚本**逐字节相同**）。
    · 因此同目录的 install.ps1 复制脚本等于空操作，它唯一的实际效果是
      用本包的模板版 SKILL.md 覆盖现场硬化版 SKILL.md —— 那会丢掉：
        1) DSH 技能加载机制的源码依据（dsh-skill-filesystem/lib/index.js:171 无条件加 ~\.dsh-beta\skills）
        2) Tee-Object 缓冲误杀 / PowerShell 读坏中文注释 / process.exit(0) 崩溃 / 管道截断量错退出码
        3) "连顾问的数字也要验"的实测案例
        4) 顾问模型清单的 --list 实测结果（新版退化为"等"）
    · 所以本脚本只做一件事：把 DEEPSEEK-GUIDE.md / EXAMPLES.md / CHECKLIST.md
      装到 <技能目录>\docs\，然后逐个 SHA256 校验。
      **不写 SKILL.md，不写 scripts\，不删任何东西。**

  为什么 docs\ 放在技能目录里而不是技能根目录：
    dsh-skill-filesystem 的 discoverRoot 只在技能根**深度 1**找条目
    ——目录取 <目录>\SKILL.md，散文件取 *.md（lib/index.js:584-617）。
    文档放进 docs\ 子目录就不会被当成第二个技能。

.PARAMETER TargetRoot
  技能根目录，默认 ~/.dsh-beta/skills，文档装到 <TargetRoot>\advisor-first\docs。

.PARAMETER SkillName
  技能目录名，默认 advisor-first。

.EXAMPLE
  pwsh -File .\install-merged.ps1
.EXAMPLE
  pwsh -File .\install-merged.ps1 -TargetRoot "$env:TEMP\skilltest"
#>
[CmdletBinding()]
param(
  [string]$TargetRoot = (Join-Path $HOME '.dsh-beta\skills'),
  [string]$SkillName  = 'advisor-first'
)

$ErrorActionPreference = 'Stop'

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $TargetRoot $SkillName

# ---- 0) 前置检查：技能必须已装，否则本脚本会造出一个没有 SKILL.md 的空壳 ----
$destSkill = Join-Path $dest 'SKILL.md'
if (-not (Test-Path $destSkill)) {
  throw "skill not installed at $dest (SKILL.md missing). Run .\install.ps1 first for a fresh install, then this script for the docs."
}

# ---- 1) 逐个确认源文件存在（缺一个就整体不装，不留半成品）----
$docs = @(
  @{ Src = Join-Path $here 'DEEPSEEK-GUIDE.md';                    Rel = 'DEEPSEEK-GUIDE.md' },
  @{ Src = Join-Path $here 'EXAMPLES.md';                          Rel = 'EXAMPLES.md' },
  @{ Src = Join-Path $here 'advisor-first-skill\CHECKLIST.md';     Rel = 'CHECKLIST.md' }
)
foreach ($d in $docs) {
  if (-not (Test-Path -LiteralPath $d.Src)) { throw "package incomplete: missing $($d.Src)" }
}

Write-Host "source : $here"
Write-Host "target : $dest\docs"
Write-Host ("skill  : {0} (SHA256 {1}, untouched)" -f $destSkill, (Get-FileHash $destSkill -Algorithm SHA256).Hash.Substring(0,16))

# ---- 2) 复制到 docs\ ----
$docsDir = Join-Path $dest 'docs'
New-Item -ItemType Directory -Path $docsDir -Force | Out-Null
foreach ($d in $docs) {
  Copy-Item -LiteralPath $d.Src -Destination (Join-Path $docsDir $d.Rel) -Force
}

# ---- 3) 写后校验：逐个 SHA256 比对 ----
$bad = @()
foreach ($d in $docs) {
  $dstFile = Join-Path $docsDir $d.Rel
  if (-not (Test-Path -LiteralPath $dstFile)) { $bad += "$($d.Rel) (missing)"; continue }
  $h1 = (Get-FileHash -LiteralPath $d.Src -Algorithm SHA256).Hash
  $h2 = (Get-FileHash -LiteralPath $dstFile -Algorithm SHA256).Hash
  $ok = ($h1 -eq $h2)
  Write-Host ("  {0,-24} {1}  {2}" -f $d.Rel, $(if ($ok) { 'OK  ' } else { 'FAIL' }), $h2.Substring(0,16))
  if (-not $ok) { $bad += $d.Rel }
}

if ($bad.Count -gt 0) {
  Write-Error "verification failed for: $($bad -join ', ')"
  exit 1
}

Write-Host ''
Write-Host 'docs installed and verified.'
Write-Host 'SKILL.md and scripts\ were NOT modified.'
Write-Host 'Rollback: delete the docs\ folder, or restore <skill>-bak-<timestamp> if you have one.'
